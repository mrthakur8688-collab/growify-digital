import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { CurrencyProvider } from './context/CurrencyContext';
import { ScrollToTop } from './components/common/ScrollToTop';
import { Navbar } from './components/layout/Navbar';
import { Footer } from './components/layout/Footer';
import { FloatingWhatsApp } from './components/layout/FloatingWhatsApp';

// Pages
import { HomePage } from './pages/HomePage';
import { AboutPage } from './pages/AboutPage';
import { ServicesIndexPage } from './pages/ServicesIndexPage';
import { WebDevelopmentPage } from './pages/services/WebDevelopmentPage';
import { UiUxDesignPage } from './pages/services/UiUxDesignPage';
import { SeoPage } from './pages/services/SeoPage';
import { LocalSeoPage } from './pages/services/LocalSeoPage';
import { GoogleAdsPage } from './pages/services/GoogleAdsPage';
import { MetaAdsPage } from './pages/services/MetaAdsPage';
import { PricingPage } from './pages/PricingPage';
import { ContactPage } from './pages/ContactPage';
import { PrivacyPolicyPage } from './pages/PrivacyPolicyPage';
import { TermsPage } from './pages/TermsPage';
import { NotFoundPage } from './pages/NotFoundPage';

export default function App() {
  return (
    <CurrencyProvider>
      <BrowserRouter>
        <ScrollToTop />
        <div className="min-h-screen flex flex-col bg-white text-[#101713] antialiased selection:bg-[#16A36A]/20 selection:text-[#075B3B]">
          <Navbar />
          <main className="flex-1">
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/about" element={<AboutPage />} />
              <Route path="/services" element={<ServicesIndexPage />} />
              <Route path="/services/web-development" element={<WebDevelopmentPage />} />
              <Route path="/services/ui-ux-design" element={<UiUxDesignPage />} />
              <Route path="/services/seo" element={<SeoPage />} />
              <Route path="/services/local-seo" element={<LocalSeoPage />} />
              <Route path="/services/google-ads" element={<GoogleAdsPage />} />
              <Route path="/services/meta-ads" element={<MetaAdsPage />} />
              <Route path="/pricing" element={<PricingPage />} />
              <Route path="/contact" element={<ContactPage />} />
              <Route path="/privacy" element={<PrivacyPolicyPage />} />
              <Route path="/terms" element={<TermsPage />} />
              <Route path="*" element={<NotFoundPage />} />
            </Routes>
          </main>
          <Footer />
          <FloatingWhatsApp />
        </div>
      </BrowserRouter>
    </CurrencyProvider>
  );
}
