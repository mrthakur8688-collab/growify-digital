import React from 'react';
import { Mail, MessageCircle, Instagram, Facebook, Linkedin, MapPin, Clock, ArrowUpRight, ShieldCheck } from 'lucide-react';
import { COMPANY_INFO } from '../data/companyData';
import { ContactForm } from '../components/common/ContactForm';
import { SEOHead } from '../components/common/SEOHead';

export const ContactPage: React.FC = () => {
  return (
    <div className="pt-24 pb-20">
      <SEOHead
        title="Contact Us — Growify Digital | Direct WhatsApp, Email & Proposals"
        description="Connect with Growify Digital and Founder Vivek Singh. Direct WhatsApp +91 9302584559, email hello.growify@gmail.com, or request a custom proposal online."
        canonicalPath="/contact"
        keywords={[
          'Contact Growify Digital',
          'Growify Digital WhatsApp',
          'Vivek Singh Contact',
          'Digital Marketing Quote India',
          'Hire Web Development Agency',
        ]}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="max-w-3xl space-y-4 mb-14">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-[#EAF8F0] text-[#075B3B] text-xs font-semibold">
            <span>Direct Channel to Leadership</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-bold tracking-tight text-[#101713] leading-tight">
            Let’s Build Something Exceptional Together
          </h1>
          <p className="text-base sm:text-lg text-[#68736C] leading-relaxed">
            Whether you need a custom website, high-converting UI/UX design, organic SEO dominance, or profitable advertising campaigns, founder Vivek Singh and our growth specialists are ready to collaborate.
          </p>
        </div>

        {/* 2-Column Contact Architecture */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          {/* Column 1: Official Direct Channels */}
          <div className="lg:col-span-5 space-y-8">
            <div className="p-8 rounded-3xl bg-neutral-50 border border-neutral-200/80 space-y-6">
              <h2 className="text-xl font-bold text-[#101713]">
                Official Agency Contacts
              </h2>

              <div className="space-y-4">
                {/* WhatsApp Direct */}
                <a
                  href={COMPANY_INFO.whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-start gap-4 p-4 rounded-2xl bg-white border border-neutral-200/80 hover:border-[#16A36A] transition-all group"
                  aria-label="Direct WhatsApp Message"
                >
                  <div className="w-10 h-10 rounded-xl bg-[#EAF8F0] text-[#16A36A] flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                    <MessageCircle className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-[#68736C]">Instant WhatsApp</div>
                    <div className="text-base font-bold text-[#101713] group-hover:text-[#16A36A] transition-colors">
                      {COMPANY_INFO.whatsappNumber}
                    </div>
                    <div className="text-[11px] text-[#16A36A] font-medium mt-0.5 flex items-center gap-1">
                      <span>Click to chat directly</span>
                      <ArrowUpRight className="w-3 h-3" />
                    </div>
                  </div>
                </a>

                {/* Email Direct */}
                <a
                  href={`mailto:${COMPANY_INFO.email}`}
                  className="flex items-start gap-4 p-4 rounded-2xl bg-white border border-neutral-200/80 hover:border-[#16A36A] transition-all group"
                  aria-label="Send direct email"
                >
                  <div className="w-10 h-10 rounded-xl bg-[#EAF8F0] text-[#16A36A] flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-[#68736C]">Official Email</div>
                    <div className="text-sm font-bold text-[#101713] break-all group-hover:text-[#16A36A] transition-colors">
                      {COMPANY_INFO.email}
                    </div>
                    <div className="text-[11px] text-[#68736C] mt-0.5">
                      Monitored daily by Vivek Singh
                    </div>
                  </div>
                </a>
              </div>

              {/* Official Social Media Profiles */}
              <div className="pt-4 border-t border-neutral-200/80">
                <div className="text-xs font-bold uppercase tracking-wider text-[#68736C] mb-3">
                  Verified Social Channels
                </div>
                <div className="grid grid-cols-3 gap-2">
                  <a
                    href={COMPANY_INFO.socials.instagram}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-3 rounded-xl bg-white border border-neutral-200 hover:border-[#16A36A] flex flex-col items-center justify-center text-center text-[#101713] hover:text-[#16A36A] transition-colors group"
                    aria-label="Instagram profile"
                  >
                    <Instagram className="w-5 h-5 text-pink-600 mb-1 group-hover:scale-110 transition-transform" />
                    <span className="text-[11px] font-semibold">Instagram</span>
                  </a>

                  <a
                    href={COMPANY_INFO.socials.facebook}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-3 rounded-xl bg-white border border-neutral-200 hover:border-[#16A36A] flex flex-col items-center justify-center text-center text-[#101713] hover:text-[#16A36A] transition-colors group"
                    aria-label="Facebook page"
                  >
                    <Facebook className="w-5 h-5 text-blue-600 mb-1 group-hover:scale-110 transition-transform" />
                    <span className="text-[11px] font-semibold">Facebook</span>
                  </a>

                  <a
                    href={COMPANY_INFO.socials.linkedin}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-3 rounded-xl bg-white border border-neutral-200 hover:border-[#16A36A] flex flex-col items-center justify-center text-center text-[#101713] hover:text-[#16A36A] transition-colors group"
                    aria-label="Vivek Singh LinkedIn"
                  >
                    <Linkedin className="w-5 h-5 text-[#0077B5] mb-1 group-hover:scale-110 transition-transform" />
                    <span className="text-[11px] font-semibold">LinkedIn</span>
                  </a>
                </div>
              </div>

              {/* Response Time Guarantee */}
              <div className="p-4 rounded-xl bg-[#EAF8F0]/70 border border-[#16A36A]/20 flex items-start gap-3 text-xs text-[#075B3B]">
                <Clock className="w-4 h-4 text-[#16A36A] shrink-0 mt-0.5" />
                <div className="leading-relaxed">
                  <strong>Fast Communication Guarantee:</strong> All initial WhatsApp inquiries and form submissions receive a response within 24 business hours.
                </div>
              </div>
            </div>

            {/* Target Territory Coverage */}
            <div className="p-6 rounded-3xl bg-white border border-neutral-200 space-y-3">
              <div className="text-xs font-bold uppercase tracking-wider text-[#16A36A]">
                International Delivery
              </div>
              <h3 className="text-sm font-bold text-[#101713]">
                Dedicated Client Coverage Across 5 Key Markets
              </h3>
              <p className="text-xs text-[#68736C] leading-relaxed">
                Growify Digital coordinates asynchronous delivery pipelines and flexible discovery calls for brands operating in India, the USA, UK, Canada, and Australia.
              </p>
            </div>
          </div>

          {/* Column 2: Lead Generation Contact Form */}
          <div className="lg:col-span-7">
            <ContactForm />
          </div>
        </div>
      </div>
    </div>
  );
};
