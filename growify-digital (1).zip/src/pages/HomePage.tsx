import React from 'react';
import { Link } from 'react-router-dom';
import {
  ArrowRight,
  Globe,
  Layers,
  Search,
  MapPin,
  Target,
  Megaphone,
  CheckCircle2,
  ShieldCheck,
  TrendingUp,
  Cpu,
  Sparkles,
  MessageCircle,
  Clock,
  Zap,
} from 'lucide-react';
import { COMPANY_INFO } from '../data/companyData';
import { SERVICES } from '../data/servicesData';
import { useCurrency } from '../context/CurrencyContext';
import { FounderSection } from '../components/common/FounderSection';
import { PricingCards } from '../components/common/PricingCards';
import { PortfolioShowcase } from '../components/common/PortfolioShowcase';
import { TestimonialsSection } from '../components/common/TestimonialsSection';
import { FAQAccordion } from '../components/common/FAQAccordion';
import { SEOHead } from '../components/common/SEOHead';

const SERVICE_ICONS: Record<string, React.ElementType> = {
  'web-development': Globe,
  'ui-ux-design': Layers,
  'seo': Search,
  'local-seo': MapPin,
  'google-ads': Target,
  'meta-ads': Megaphone,
};

export const HomePage: React.FC = () => {
  const { currency, formatStartingPrice } = useCurrency();

  const generalFAQs = [
    {
      question: 'What types of businesses does Growify Digital work with?',
      answer:
        'We collaborate with ambitious startups, growing small-to-medium enterprises, e-commerce stores, healthcare practices, and B2B service firms across India, the United States, United Kingdom, Canada, and Australia.',
    },
    {
      question: 'How do you handle international clients across different time zones?',
      answer:
        'Our delivery workflows are built for global efficiency. We leverage asynchronous video updates, transparent project boards, dedicated WhatsApp groups, and flexible scheduling for discovery calls.',
    },
    {
      question: 'Do you guarantee #1 rankings or specific marketing sales numbers?',
      answer:
        'No ethical agency can guarantee specific sales figures or #1 Google rankings because third-party algorithms and market factors evolve continuously. What we guarantee is rigorous, data-driven execution, transparent reporting, and white-hat methodologies designed for sustainable ROI.',
    },
    {
      question: 'How is advertising spend handled for Google and Meta Ads?',
      answer:
        'Ad spend is paid directly by you to the ad platforms (Google Ads / Meta Business Manager) via your own billing credentials. Our fee is strictly a management retainer for campaign architecture, creative production, targeting, and daily optimization.',
    },
  ];

  return (
    <div className="pt-20">
      <SEOHead
        title="Growify Digital — Premium International Digital Growth Agency"
        description="We Build Digital Experiences That Grow Businesses. High-performance web development, UI/UX design, SEO, and Google & Meta Ads for ambitious brands."
        canonicalPath="/"
        keywords={[
          'Digital Marketing Agency',
          'Digital Marketing Agency India',
          'Website Development Company',
          'SEO Services',
          'Google Ads Management',
          'Meta Ads Agency',
          'Digital Marketing Agency USA',
        ]}
      />

      {/* Hero Section */}
      <section className="relative overflow-hidden pt-12 pb-20 sm:pt-20 sm:pb-28 bg-radial from-[#EAF8F0]/40 via-white to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-4xl mx-auto space-y-6">
            {/* Top Tagline */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#EAF8F0] border border-[#16A36A]/20 text-[#075B3B] text-xs font-semibold">
              <span className="w-2 h-2 rounded-full bg-[#16A36A]"></span>
              <span>Premium International Digital Growth Agency</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-4xl sm:text-6xl lg:text-7xl font-bold tracking-tight text-[#101713] leading-[1.08] text-balance">
              We Build Digital Experiences That{' '}
              <span className="text-[#16A36A] relative inline-block">
                Grow Businesses
                <span className="absolute bottom-1 left-0 right-0 h-2 bg-[#16A36A]/10 -z-10 rounded"></span>
              </span>
              .
            </h1>

            {/* Supporting Text */}
            <p className="text-base sm:text-xl text-[#68736C] max-w-2xl mx-auto leading-relaxed text-balance">
              {COMPANY_INFO.subtagline}
            </p>

            {/* CTA Buttons */}
            <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link
                to="/services"
                className="w-full sm:w-auto px-8 py-4 rounded-xl text-xs sm:text-sm font-bold text-white bg-[#16A36A] hover:bg-[#075B3B] transition-all shadow-md hover:shadow-lg flex items-center justify-center gap-2 group"
              >
                <span>Explore Our Services</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Link>

              <Link
                to="/contact"
                className="w-full sm:w-auto px-8 py-4 rounded-xl text-xs sm:text-sm font-bold text-[#101713] bg-white hover:bg-neutral-50 border border-neutral-200 transition-colors shadow-2xs flex items-center justify-center gap-2"
              >
                <span>Book a Free Consultation</span>
              </Link>
            </div>

            {/* Target Markets Line */}
            <div className="pt-8 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-xs text-[#68736C]">
              <span className="font-semibold text-[#101713]">Serving Ambitious Brands in:</span>
              {COMPANY_INFO.targetMarkets.map((m) => (
                <span key={m.country} className="inline-flex items-center gap-1 font-medium">
                  <span>{m.flag}</span>
                  <span>{m.country}</span>
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Subtle decorative background gradient circles */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] bg-gradient-to-tr from-emerald-100/30 to-teal-100/20 rounded-full blur-3xl -z-10 pointer-events-none"></div>
      </section>

      {/* Trust & Value Pillars */}
      <section className="py-12 bg-white border-y border-neutral-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="p-5 rounded-2xl bg-neutral-50 border border-neutral-100/80">
              <div className="w-8 h-8 rounded-lg bg-[#EAF8F0] text-[#16A36A] flex items-center justify-center mb-3">
                <Sparkles className="w-4 h-4" />
              </div>
              <h3 className="text-sm font-bold text-[#101713]">Creative Digital Solutions</h3>
              <p className="mt-1 text-xs text-[#68736C]">
                Bespoke design systems and custom architectures tailored to your brand equity.
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-neutral-50 border border-neutral-100/80">
              <div className="w-8 h-8 rounded-lg bg-[#EAF8F0] text-[#16A36A] flex items-center justify-center mb-3">
                <Target className="w-4 h-4" />
              </div>
              <h3 className="text-sm font-bold text-[#101713]">Strategic Thinking</h3>
              <p className="mt-1 text-xs text-[#68736C]">
                Commercial alignment before execution to protect marketing investments.
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-neutral-50 border border-neutral-100/80">
              <div className="w-8 h-8 rounded-lg bg-[#EAF8F0] text-[#16A36A] flex items-center justify-center mb-3">
                <TrendingUp className="w-4 h-4" />
              </div>
              <h3 className="text-sm font-bold text-[#101713]">Performance Focused</h3>
              <p className="mt-1 text-xs text-[#68736C]">
                Engineered for speed, search indexation, and real customer conversions.
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-neutral-50 border border-neutral-100/80">
              <div className="w-8 h-8 rounded-lg bg-[#EAF8F0] text-[#16A36A] flex items-center justify-center mb-3">
                <Globe className="w-4 h-4" />
              </div>
              <h3 className="text-sm font-bold text-[#101713]">International Vision</h3>
              <p className="mt-1 text-xs text-[#68736C]">
                Global standards with tailored pricing for India and international markets.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 bg-white" id="services">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16">
            <div className="max-w-2xl">
              <div className="text-xs font-bold uppercase tracking-wider text-[#16A36A] mb-2">
                Core Capabilities
              </div>
              <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-[#101713]">
                Six Specialized Services Built for Growth
              </h2>
              <p className="mt-3 text-base text-[#68736C]">
                Every service is backed by dedicated technical methodologies, transparent deliverables, and continuous optimization.
              </p>
            </div>

            <Link
              to="/services"
              className="inline-flex items-center gap-1.5 text-xs font-bold text-[#16A36A] hover:text-[#075B3B] hover:underline"
            >
              <span>Explore All 6 Services</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          {/* 6 Service Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {SERVICES.map((s, idx) => {
              const Icon = SERVICE_ICONS[s.id] || Globe;
              const priceDisplay = formatStartingPrice(s.startingPriceINR, s.startingPriceUSD, s.billingPeriod);

              return (
                <div
                  key={s.id}
                  className="rounded-3xl p-8 bg-white border border-neutral-200 hover:border-[#16A36A]/50 hover:shadow-xl transition-all duration-300 flex flex-col justify-between group"
                >
                  <div>
                    <div className="w-12 h-12 rounded-2xl bg-[#EAF8F0] text-[#16A36A] flex items-center justify-center mb-6 group-hover:scale-105 transition-transform">
                      <Icon className="w-6 h-6" />
                    </div>

                    <div className="text-xs text-[#68736C] mb-1 font-mono">0{idx + 1}.</div>
                    <h3 className="text-xl font-bold text-[#101713] group-hover:text-[#16A36A] transition-colors">
                      {s.title}
                    </h3>

                    <p className="mt-2 text-xs text-[#68736C] leading-relaxed line-clamp-3">
                      {s.shortDesc}
                    </p>

                    {/* Price preview */}
                    <div className="mt-6 pt-4 border-t border-neutral-100 flex items-center justify-between text-xs">
                      <span className="text-[#68736C]">Baseline:</span>
                      <span className="font-bold text-[#101713]">{priceDisplay}</span>
                    </div>
                  </div>

                  <div className="mt-6 pt-4 border-t border-neutral-100 flex items-center justify-between">
                    <Link
                      to={`/services/${s.slug}`}
                      className="text-xs font-bold text-[#16A36A] group-hover:text-[#075B3B] inline-flex items-center gap-1"
                    >
                      <span>Explore Service</span>
                      <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                    </Link>

                    <Link
                      to={`/contact?service=${s.slug}`}
                      className="text-xs text-[#68736C] hover:text-[#101713]"
                    >
                      Get Quote &rarr;
                    </Link>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Why Choose Growify */}
      <section className="py-20 bg-neutral-50/60 border-y border-neutral-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <div className="text-xs font-bold uppercase tracking-wider text-[#16A36A] mb-2">
              Our Agency Standard
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-[#101713]">
              Why Choose Growify Digital
            </h2>
            <p className="mt-3 text-base text-[#68736C]">
              We reject bloated agency fluff and replace it with agile craftsmanship, clean code, and accountable communication.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {COMPANY_INFO.values.map((v, idx) => (
              <div
                key={idx}
                className="p-6 rounded-2xl bg-white border border-neutral-200/80 shadow-2xs space-y-3"
              >
                <div className="w-8 h-8 rounded-lg bg-[#EAF8F0] text-[#075B3B] font-bold text-xs flex items-center justify-center">
                  0{idx + 1}
                </div>
                <h3 className="text-base font-bold text-[#101713]">{v.title}</h3>
                <p className="text-xs text-[#68736C] leading-relaxed">{v.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Our 5-Step Process */}
      <section className="py-20 bg-white" id="process">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <div className="text-xs font-bold uppercase tracking-wider text-[#16A36A] mb-2">
              End-To-End Methodology
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-[#101713]">
              How We Turn Ideas into Growth
            </h2>
            <p className="mt-3 text-base text-[#68736C]">
              From initial audit to post-launch scaling, our 5-phase roadmap ensures seamless execution.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
            {COMPANY_INFO.process.map((step) => (
              <div
                key={step.step}
                className="relative p-6 rounded-2xl bg-neutral-50 border border-neutral-200/80 flex flex-col justify-between"
              >
                <div>
                  <div className="text-3xl font-extrabold text-[#16A36A] mb-3">{step.step}</div>
                  <h3 className="text-lg font-bold text-[#101713] mb-1">{step.name}</h3>
                  <div className="text-xs font-medium text-[#16A36A] mb-2">{step.tagline}</div>
                  <p className="text-xs text-[#68736C] leading-relaxed">{step.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Portfolio Demonstration Showcase */}
      <section className="py-20 bg-neutral-50/60 border-y border-neutral-100" id="portfolio">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <div className="text-xs font-bold uppercase tracking-wider text-[#16A36A] mb-2">
              Demonstration Showcase
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-[#101713]">
              Crafted With Speed & Precision
            </h2>
            <p className="mt-3 text-base text-[#68736C]">
              Explore our architectural and design demonstration models illustrating our visual quality standards and conversion frameworks.
            </p>
          </div>

          <PortfolioShowcase />
        </div>
      </section>

      {/* Founder Section — Vivek Singh */}
      <FounderSection />

      {/* Pricing Preview Section with Currency Switcher */}
      <section className="py-20 bg-white" id="pricing">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <PricingCards showTitle={true} />
        </div>
      </section>

      {/* Testimonials (Sample Placeholders) */}
      <section className="py-20 bg-neutral-50/60 border-y border-neutral-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <TestimonialsSection />
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-white" id="faqs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <div className="text-xs font-bold uppercase tracking-wider text-[#16A36A] mb-2">
              Clarity & Transparency
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-[#101713]">
              Frequently Asked Questions
            </h2>
            <p className="mt-3 text-sm text-[#68736C]">
              Clear answers regarding our services, commercial engagements, and international client workflows.
            </p>
          </div>

          <div className="max-w-3xl mx-auto">
            <FAQAccordion faqs={generalFAQs} includeSchema={true} />
          </div>
        </div>
      </section>

      {/* Final Call to Action */}
      <section className="py-20 bg-[#101713] text-white">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-neutral-900 border border-neutral-800 text-xs text-emerald-400 font-semibold">
            <span>Next Steps</span>
            <span>·</span>
            <span>Zero-Obligation Proposal</span>
          </div>

          <h2 className="text-3xl sm:text-5xl font-bold tracking-tight leading-tight">
            Ready to Grow Your Business?
          </h2>

          <p className="text-base sm:text-lg text-neutral-300 max-w-2xl mx-auto leading-relaxed">
            Let’s talk about your project. Connect directly with Vivek Singh or submit your project details for a tailored strategic blueprint.
          </p>

          <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              to="/contact"
              className="w-full sm:w-auto px-8 py-4 rounded-xl text-xs sm:text-sm font-bold text-[#075B3B] bg-white hover:bg-neutral-100 transition-colors shadow-lg"
            >
              Let’s Talk About Your Project
            </Link>

            <a
              href={COMPANY_INFO.whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto px-8 py-4 rounded-xl text-xs sm:text-sm font-bold text-white bg-[#16A36A] hover:bg-[#075B3B] transition-colors flex items-center justify-center gap-2"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Instant WhatsApp Chat</span>
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};
