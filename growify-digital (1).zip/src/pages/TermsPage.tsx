import React from 'react';
import { Link } from 'react-router-dom';
import { ShieldCheck, ChevronRight } from 'lucide-react';
import { COMPANY_INFO } from '../data/companyData';
import { SEOHead } from '../components/common/SEOHead';

export const TermsPage: React.FC = () => {
  return (
    <div className="pt-24 pb-20">
      <SEOHead
        title="Terms & Conditions — Growify Digital"
        description="Terms and conditions governing web development, UI/UX design, SEO, and digital marketing services provided by Growify Digital."
        canonicalPath="/terms"
      />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <nav className="flex items-center gap-2 text-xs text-[#68736C] mb-8">
          <Link to="/" className="hover:text-[#101713] transition-colors">
            Home
          </Link>
          <ChevronRight className="w-3.5 h-3.5" />
          <span className="text-[#101713] font-semibold">Terms & Conditions</span>
        </nav>

        <div className="border-b border-neutral-100 pb-8 mb-8">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-[#EAF8F0] text-[#075B3B] text-xs font-semibold mb-3">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Commercial Agreement</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-[#101713]">
            Terms & Conditions
          </h1>
          <p className="mt-2 text-xs text-[#68736C]">
            Effective Date: November 1, 2026 · Growify Digital (Founder: Vivek Singh)
          </p>
        </div>

        <div className="prose prose-neutral max-w-none text-xs sm:text-sm text-[#68736C] space-y-6 leading-relaxed">
          <section className="space-y-2">
            <h2 className="text-base sm:text-lg font-bold text-[#101713]">1. Agreement to Terms</h2>
            <p>
              By accessing the website of Growify Digital (growifydigital.com) or entering into an agreement for services with Growify Digital (founded by Vivek Singh), you agree to be bound by these Terms & Conditions. If you do not agree to these terms, please refrain from using our website and services.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="text-base sm:text-lg font-bold text-[#101713]">2. Scope of Services & Custom Proposals</h2>
            <p>
              Growify Digital provides professional digital services including Website Development, UI/UX Design, Search Engine Optimization (SEO), Local SEO, Google Ads Management, and Meta Ads Management.
            </p>
            <p>
              All prices displayed on the website are baseline estimates marked with <strong>“Starting From”</strong>. They do not constitute a fixed, binding quotation. Final binding pricing, milestones, deliverables, and revision terms are established solely within an itemized formal written proposal or statement of work (SOW) executed between Growify Digital and the client.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="text-base sm:text-lg font-bold text-[#101713]">3. Advertising Media Spend Separation</h2>
            <p>
              For paid acquisition services (Google Ads and Meta Ads), agency retainer fees represent compensation solely for strategic planning, ad creation, targeting setup, tracking maintenance, bid optimization, and reporting.
            </p>
            <p>
              <strong>Direct Ad Spend:</strong> All media advertising spend is paid directly by the client to Google or Meta through the client’s own payment method. Growify Digital does not absorb or advance client ad budgets.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="text-base sm:text-lg font-bold text-[#101713]">4. Marketing Performance & Disclaimers</h2>
            <p>
              Growify Digital employs industry-standard best practices, data analytics, and ethical white-hat frameworks. However, because search engine ranking algorithms (Google, Bing), advertising auction dynamics (Meta, Google), and user conversion behaviors are inherently variable and outside our unilateral control, Growify Digital does not make claims of guaranteed sales volumes, revenue multipliers, or guaranteed #1 search engine positions.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="text-base sm:text-lg font-bold text-[#101713]">5. Intellectual Property & Code Ownership</h2>
            <p>
              Upon receipt of full final payment for custom website development or design projects, all final code deliverables, Figma designs, and creative assets produced specifically for the client become the proprietary property of the client. Growify Digital reserves the customary right to showcase non-confidential project visuals as part of its agency portfolio.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="text-base sm:text-lg font-bold text-[#101713]">6. Client Responsibilities & Materials</h2>
            <p>
              The client agrees to provide necessary text copy, brand imagery, logos, and account access in a timely manner. Delays in client feedback or material provisioning may extend estimated project delivery milestones.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="text-base sm:text-lg font-bold text-[#101713]">7. Contact Information</h2>
            <p>
              For legal notices, contract inquiries, or clarifications:
            </p>
            <div className="p-4 rounded-xl bg-neutral-50 border border-neutral-200 text-xs text-[#101713] space-y-1">
              <div><strong>Growify Digital</strong> (Founder: Vivek Singh)</div>
              <div>Email: <a href={`mailto:${COMPANY_INFO.email}`} className="text-[#16A36A] underline">{COMPANY_INFO.email}</a></div>
              <div>WhatsApp: <a href={COMPANY_INFO.whatsappUrl} className="text-[#16A36A] underline">{COMPANY_INFO.whatsappNumber}</a></div>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};
