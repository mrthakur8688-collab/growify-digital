import React from 'react';
import { Link } from 'react-router-dom';
import { Globe, Layers, Search, MapPin, Target, Megaphone, ArrowRight, CheckCircle2, MessageCircle } from 'lucide-react';
import { SERVICES } from '../data/servicesData';
import { COMPANY_INFO } from '../data/companyData';
import { useCurrency } from '../context/CurrencyContext';
import { SEOHead } from '../components/common/SEOHead';

const SERVICE_ICONS: Record<string, React.ElementType> = {
  'web-development': Globe,
  'ui-ux-design': Layers,
  'seo': Search,
  'local-seo': MapPin,
  'google-ads': Target,
  'meta-ads': Megaphone,
};

export const ServicesIndexPage: React.FC = () => {
  const { formatStartingPrice, currency } = useCurrency();

  return (
    <div className="pt-24 pb-20">
      <SEOHead
        title="Our Services — Growify Digital | Complete Digital Growth Solutions"
        description="Explore Growify Digital's 6 core services: Website Development, UI/UX Design, SEO, Local SEO, Google Ads Management, and Meta Ads Management."
        canonicalPath="/services"
        keywords={[
          'Digital Marketing Services',
          'Web Development Company',
          'UI UX Agency',
          'SEO Services',
          'Google Ads Management',
          'Meta Ads Agency',
        ]}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Page Header */}
        <div className="max-w-3xl space-y-4 mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-[#EAF8F0] text-[#075B3B] text-xs font-semibold">
            <span>Specialized Capabilities</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-bold tracking-tight text-[#101713] leading-tight">
            Comprehensive Growth Services for Modern Enterprises
          </h1>
          <p className="text-base sm:text-lg text-[#68736C] leading-relaxed">
            Every service we offer is engineered around tangible commercial impact. Explore our six core service practices below to learn about our diagnostic process, deliverables, and starting investments.
          </p>
        </div>

        {/* 6 Services Deep-Dive Cards */}
        <div className="space-y-12">
          {SERVICES.map((s, idx) => {
            const Icon = SERVICE_ICONS[s.id] || Globe;
            const priceFormatted = formatStartingPrice(
              s.startingPriceINR,
              s.startingPriceUSD,
              s.billingPeriod
            );

            return (
              <div
                key={s.id}
                className="rounded-3xl p-8 sm:p-10 bg-white border border-neutral-200 hover:border-[#16A36A]/50 shadow-sm hover:shadow-xl transition-all duration-300 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center"
              >
                <div className="lg:col-span-8 space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-[#EAF8F0] text-[#16A36A] flex items-center justify-center">
                      <Icon className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="text-xs font-mono text-[#68736C]">0{idx + 1}</span>
                      <h2 className="text-2xl font-bold text-[#101713]">{s.title}</h2>
                    </div>
                  </div>

                  <p className="text-sm font-medium text-[#16A36A]">{s.tagline}</p>
                  <p className="text-xs sm:text-sm text-[#68736C] leading-relaxed max-w-2xl">
                    {s.fullDesc}
                  </p>

                  {/* Highlights */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2">
                    {s.deliverables.slice(0, 4).map((d, dIdx) => (
                      <div key={dIdx} className="flex items-center gap-2 text-xs text-[#101713]">
                        <CheckCircle2 className="w-3.5 h-3.5 text-[#16A36A] shrink-0" />
                        <span className="truncate">{d}</span>
                      </div>
                    ))}
                  </div>

                  <div className="pt-4 flex flex-wrap items-center gap-3">
                    <Link
                      to={`/services/${s.slug}`}
                      className="px-5 py-2.5 rounded-xl text-xs font-bold text-white bg-[#16A36A] hover:bg-[#075B3B] transition-colors inline-flex items-center gap-1.5 shadow-2xs"
                    >
                      <span>View Full Service Page</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </Link>

                    <Link
                      to={`/contact?service=${s.slug}`}
                      className="px-4 py-2.5 rounded-xl text-xs font-semibold text-[#101713] bg-neutral-100 hover:bg-neutral-200 transition-colors"
                    >
                      Request Quote
                    </Link>

                    <a
                      href={`https://wa.me/${COMPANY_INFO.whatsappRaw}?text=Hello%20Growify%20Digital!%20I%E2%80%99m%20interested%20in%20your%20${encodeURIComponent(
                        s.title
                      )}%20service.`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-2.5 text-[#16A36A] hover:bg-[#EAF8F0] rounded-xl transition-colors inline-flex items-center gap-1 text-xs font-semibold"
                      title="Enquire on WhatsApp"
                    >
                      <MessageCircle className="w-4 h-4" />
                      <span>WhatsApp</span>
                    </a>
                  </div>
                </div>

                {/* Investment Side Card */}
                <div className="lg:col-span-4 p-6 rounded-2xl bg-neutral-50 border border-neutral-200/80 space-y-4">
                  <div className="text-xs font-bold uppercase tracking-wider text-[#68736C]">
                    Service Rate
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-[#101713]">{priceFormatted}</div>
                    <div className="text-[11px] text-[#68736C] mt-1">
                      {currency === 'INR' ? 'Domestic Tier (INR)' : 'International Tier (USD)'}
                    </div>
                  </div>
                  <div className="text-xs text-[#68736C] border-t border-neutral-200/60 pt-3">
                    Includes dedicated account manager, milestone deliverables, and post-delivery review.
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
