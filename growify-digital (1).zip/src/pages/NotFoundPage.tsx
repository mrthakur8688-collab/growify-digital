import React from 'react';
import { Link } from 'react-router-dom';
import { Home, ArrowLeft, Globe, Search } from 'lucide-react';
import { SEOHead } from '../components/common/SEOHead';
import { SERVICES } from '../data/servicesData';

export const NotFoundPage: React.FC = () => {
  return (
    <div className="min-h-[75vh] flex items-center justify-center pt-28 pb-20 px-4">
      <SEOHead
        title="404 — Page Not Found | Growify Digital"
        description="The requested page could not be located on Growify Digital. Return home or browse our specialized services."
        canonicalPath="/404"
      />

      <div className="max-w-md w-full text-center space-y-6">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-3xl bg-[#EAF8F0] text-[#16A36A] font-extrabold text-2xl">
          404
        </div>

        <div className="space-y-2">
          <h1 className="text-2xl sm:text-3xl font-bold text-[#101713]">
            Page Not Found
          </h1>
          <p className="text-xs sm:text-sm text-[#68736C] leading-relaxed">
            The page you are searching for might have been moved, renamed, or is temporarily unavailable.
          </p>
        </div>

        <div className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200/80 text-left space-y-2">
          <div className="text-xs font-bold text-[#101713] uppercase tracking-wider">
            Quick Navigation:
          </div>
          <div className="grid grid-cols-2 gap-2 text-xs">
            {SERVICES.slice(0, 4).map((s) => (
              <Link
                key={s.id}
                to={`/services/${s.slug}`}
                className="text-[#68736C] hover:text-[#16A36A] truncate"
              >
                &bull; {s.title}
              </Link>
            ))}
          </div>
        </div>

        <div className="flex items-center justify-center gap-3">
          <Link
            to="/"
            className="px-6 py-3 rounded-xl text-xs font-bold text-white bg-[#16A36A] hover:bg-[#075B3B] transition-colors flex items-center gap-2"
          >
            <Home className="w-4 h-4" />
            <span>Return to Home</span>
          </Link>
          <Link
            to="/services"
            className="px-5 py-3 rounded-xl text-xs font-semibold text-[#101713] bg-neutral-100 hover:bg-neutral-200 transition-colors"
          >
            All Services
          </Link>
        </div>
      </div>
    </div>
  );
};
