import React from 'react';
import { PricingCards } from '../components/common/PricingCards';
import { FAQAccordion } from '../components/common/FAQAccordion';
import { SEOHead } from '../components/common/SEOHead';
import { ShieldCheck, HelpCircle, ArrowRight, MessageCircle } from 'lucide-react';
import { COMPANY_INFO } from '../data/companyData';
import { Link } from 'react-router-dom';

export const PricingPage: React.FC = () => {
  const pricingFAQs = [
    {
      question: 'Why are all listed prices marked "Starting From"?',
      answer:
        'Every business has unique scope requirements, technical complexity, custom design needs, and target timelines. Starting rates reflect our baseline minimum engagement size for each discipline. We provide an exact itemized quotation following a project discovery call.',
    },
    {
      question: 'Is advertising spend included in the monthly management fee?',
      answer:
        'No. Advertising spend is billed directly by Google Ads or Meta Ads to your corporate card. Our agency fee covers strategic planning, copywriting, creative graphic design, audience targeting, tracking installation, bid adjustments, and performance reporting.',
    },
    {
      question: 'What payment methods do you accept for international clients?',
      answer:
        'For clients in the United States, United Kingdom, Canada, Australia, and worldwide, we accept international wire transfers, Stripe credit card invoices, and PayPal. For clients in India, we accept UPI, NEFT/IMPS bank transfer, and major cards.',
    },
    {
      question: 'Are there any hidden costs or surprise agency markups?',
      answer:
        'None. We operate on 100% price transparency. Your formal written proposal will list all milestones, deliverables, and included revisions before any work begins.',
    },
  ];

  return (
    <div className="pt-24 pb-20">
      <SEOHead
        title="International Pricing — Growify Digital | India & Global Rates"
        description="Transparent digital marketing and website development pricing for India (INR) and International clients (USD). Website development from ₹15,000 / $299."
        canonicalPath="/pricing"
        keywords={[
          'Digital Marketing Pricing',
          'Website Development Cost India',
          'SEO Pricing USD',
          'Google Ads Management Cost',
          'Meta Ads Retainer Pricing',
        ]}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <PricingCards showTitle={true} />

        {/* Pricing FAQs */}
        <div className="mt-20 pt-16 border-t border-neutral-100">
          <div className="max-w-2xl mb-10">
            <div className="text-xs font-bold uppercase tracking-wider text-[#16A36A] mb-2">
              Commercial Clarity
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold text-[#101713]">
              Frequently Asked Questions About Pricing
            </h2>
            <p className="mt-2 text-sm text-[#68736C]">
              Everything you need to know about our billing terms, payment workflows, and engagement scopes.
            </p>
          </div>

          <div className="max-w-3xl">
            <FAQAccordion faqs={pricingFAQs} includeSchema={true} />
          </div>
        </div>

        {/* Custom Proposal CTA */}
        <div className="mt-16 p-8 sm:p-12 rounded-3xl bg-[#101713] text-white flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2">
            <h3 className="text-2xl font-bold">Require a Customized Multi-Service Bundle?</h3>
            <p className="text-sm text-neutral-300">
              Combine Website Development with ongoing SEO and Paid Advertising for preferred growth rates.
            </p>
          </div>
          <div className="flex items-center gap-3">
            <Link
              to="/contact"
              className="px-6 py-3 rounded-xl text-xs font-bold text-[#075B3B] bg-white hover:bg-neutral-100 transition-colors"
            >
              Request Custom Quote
            </Link>
            <a
              href={COMPANY_INFO.whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-6 py-3 rounded-xl text-xs font-bold text-white bg-[#16A36A] hover:bg-[#075B3B] transition-colors flex items-center gap-1.5"
            >
              <MessageCircle className="w-4 h-4" />
              <span>WhatsApp Chat</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
