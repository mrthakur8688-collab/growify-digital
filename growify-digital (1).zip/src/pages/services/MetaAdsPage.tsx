import React from 'react';
import { SERVICES } from '../../data/servicesData';
import { ServiceDetailTemplate } from '../../components/services/ServiceDetailTemplate';

export const MetaAdsPage: React.FC = () => {
  const service = SERVICES.find((s) => s.slug === 'meta-ads')!;
  return <ServiceDetailTemplate service={service} />;
};
