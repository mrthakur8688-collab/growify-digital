import React from 'react';
import { SERVICES } from '../../data/servicesData';
import { ServiceDetailTemplate } from '../../components/services/ServiceDetailTemplate';

export const GoogleAdsPage: React.FC = () => {
  const service = SERVICES.find((s) => s.slug === 'google-ads')!;
  return <ServiceDetailTemplate service={service} />;
};
