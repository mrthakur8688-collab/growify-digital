import React from 'react';
import { SERVICES } from '../../data/servicesData';
import { ServiceDetailTemplate } from '../../components/services/ServiceDetailTemplate';

export const WebDevelopmentPage: React.FC = () => {
  const service = SERVICES.find((s) => s.slug === 'web-development')!;
  return <ServiceDetailTemplate service={service} />;
};
