import React from 'react';
import { SERVICES } from '../../data/servicesData';
import { ServiceDetailTemplate } from '../../components/services/ServiceDetailTemplate';

export const SeoPage: React.FC = () => {
  const service = SERVICES.find((s) => s.slug === 'seo')!;
  return <ServiceDetailTemplate service={service} />;
};
