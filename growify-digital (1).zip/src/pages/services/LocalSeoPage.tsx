import React from 'react';
import { SERVICES } from '../../data/servicesData';
import { ServiceDetailTemplate } from '../../components/services/ServiceDetailTemplate';

export const LocalSeoPage: React.FC = () => {
  const service = SERVICES.find((s) => s.slug === 'local-seo')!;
  return <ServiceDetailTemplate service={service} />;
};
