import React from 'react';
import { SERVICES } from '../../data/servicesData';
import { ServiceDetailTemplate } from '../../components/services/ServiceDetailTemplate';

export const UiUxDesignPage: React.FC = () => {
  const service = SERVICES.find((s) => s.slug === 'ui-ux-design')!;
  return <ServiceDetailTemplate service={service} />;
};
