import React from 'react';
import { Link } from 'react-router-dom';
import { COMPANY_INFO } from '../data/companyData';
import { FounderSection } from '../components/common/FounderSection';
import { SEOHead } from '../components/common/SEOHead';
import { ShieldCheck, Target, Globe, Compass, ArrowRight, MessageCircle } from 'lucide-react';

export const AboutPage: React.FC = () => {
  return (
    <div className="pt-24 pb-20">
      <SEOHead
        title="About Us — Growify Digital | Premium Growth Agency Founded by Vivek Singh"
        description="Learn about Growify Digital, an international digital growth agency founded by Vivek Singh, helping businesses in India, US, UK, Canada, and Australia scale online."
        canonicalPath="/about"
        keywords={[
          'About Growify Digital',
          'Vivek Singh Founder',
          'Digital Marketing Agency India',
          'International Digital Agency',
          'Growify Agency Vision',
        ]}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* About Hero Header */}
        <div className="max-w-3xl space-y-4 mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-[#EAF8F0] text-[#075B3B] text-xs font-semibold">
            <span>Our Origin & Purpose</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-bold tracking-tight text-[#101713] leading-tight">
            We Help Forward-Thinking Businesses Scale Their Digital Footprint
          </h1>
          <p className="text-base sm:text-lg text-[#68736C] leading-relaxed">
            Growify Digital was founded by Vivek Singh with a singular ambition: to bridge the gap between creative visual elegance and commercially disciplined performance marketing.
          </p>
        </div>

        {/* Story Section */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center py-12 border-y border-neutral-100">
          <div className="lg:col-span-7 space-y-6">
            <h2 className="text-2xl sm:text-3xl font-bold text-[#101713]">
              The Growify Philosophy
            </h2>
            <p className="text-sm sm:text-base text-[#68736C] leading-relaxed">
              In an era dominated by cookie-cutter AI templates and generic marketing campaigns, modern businesses need distinct brand presence combined with engineering precision.
            </p>
            <p className="text-sm sm:text-base text-[#68736C] leading-relaxed">
              We operate as a high-velocity digital partner for ambitious teams across India, the United States, the United Kingdom, Canada, and Australia. By harmonizing bespoke web development, conversion-driven UI/UX design, organic search optimization, and disciplined ad spend, we deliver predictable pipelines instead of vanity metrics.
            </p>

            <div className="pt-2 grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-4 rounded-xl bg-neutral-50 border border-neutral-200/80">
                <div className="font-bold text-sm text-[#101713]">Strategy Before Code</div>
                <div className="text-xs text-[#68736C] mt-1">
                  We audit your competitive landscape and customer friction points before architecting solutions.
                </div>
              </div>
              <div className="p-4 rounded-xl bg-neutral-50 border border-neutral-200/80">
                <div className="font-bold text-sm text-[#101713]">Radical Accountability</div>
                <div className="text-xs text-[#68736C] mt-1">
                  Direct client access to lead specialists, transparent reporting, and zero hidden markups.
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-5 p-8 rounded-3xl bg-[#EAF8F0]/60 border border-[#16A36A]/20 space-y-4">
            <div className="text-xs font-bold uppercase tracking-wider text-[#075B3B]">
              International Reach
            </div>
            <h3 className="text-xl font-bold text-[#101713]">
              Targeted Global Market Delivery
            </h3>
            <p className="text-xs text-[#68736C] leading-relaxed">
              Our workflows and international pricing structures cater to dynamic businesses across key growth territories:
            </p>
            <div className="space-y-2 pt-2">
              {COMPANY_INFO.targetMarkets.map((m) => (
                <div
                  key={m.country}
                  className="flex items-center justify-between p-3 rounded-xl bg-white border border-neutral-200/70 text-xs font-semibold text-[#101713]"
                >
                  <div className="flex items-center gap-2">
                    <span className="text-base">{m.flag}</span>
                    <span>{m.country}</span>
                  </div>
                  <span className="text-neutral-500 font-normal">
                    {m.currency === 'INR' ? 'Domestic Tier (INR ₹)' : 'International Tier (USD $)'}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Founder Section Embedded */}
        <div className="pt-8">
          <FounderSection />
        </div>

        {/* CTA Banner */}
        <div className="mt-16 p-8 sm:p-12 rounded-3xl bg-[#101713] text-white flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2">
            <h3 className="text-2xl font-bold">Partner with Growify Digital</h3>
            <p className="text-sm text-neutral-300">
              Ready to elevate your digital presence? Speak directly with founder Vivek Singh.
            </p>
          </div>
          <div className="flex items-center gap-3">
            <Link
              to="/contact"
              className="px-6 py-3 rounded-xl text-xs font-bold text-[#075B3B] bg-white hover:bg-neutral-100 transition-colors"
            >
              Get Custom Quote
            </Link>
            <a
              href={COMPANY_INFO.whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-6 py-3 rounded-xl text-xs font-bold text-white bg-[#16A36A] hover:bg-[#075B3B] transition-colors flex items-center gap-1.5"
            >
              <MessageCircle className="w-4 h-4" />
              <span>WhatsApp Chat</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
