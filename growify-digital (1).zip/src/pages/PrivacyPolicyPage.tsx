import React from 'react';
import { Link } from 'react-router-dom';
import { ShieldCheck, Mail, MessageCircle, ChevronRight } from 'lucide-react';
import { COMPANY_INFO } from '../data/companyData';
import { SEOHead } from '../components/common/SEOHead';

export const PrivacyPolicyPage: React.FC = () => {
  return (
    <div className="pt-24 pb-20">
      <SEOHead
        title="Privacy Policy — Growify Digital"
        description="Privacy policy and data handling guidelines for Growify Digital. Learn how we protect client information and maintain confidentiality."
        canonicalPath="/privacy"
      />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <nav className="flex items-center gap-2 text-xs text-[#68736C] mb-8">
          <Link to="/" className="hover:text-[#101713] transition-colors">
            Home
          </Link>
          <ChevronRight className="w-3.5 h-3.5" />
          <span className="text-[#101713] font-semibold">Privacy Policy</span>
        </nav>

        <div className="border-b border-neutral-100 pb-8 mb-8">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-[#EAF8F0] text-[#075B3B] text-xs font-semibold mb-3">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Client Confidentiality & Privacy</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-[#101713]">
            Privacy Policy
          </h1>
          <p className="mt-2 text-xs text-[#68736C]">
            Effective Date: November 1, 2026 · Growify Digital (Founder: Vivek Singh)
          </p>
        </div>

        <div className="prose prose-neutral max-w-none text-xs sm:text-sm text-[#68736C] space-y-6 leading-relaxed">
          <section className="space-y-2">
            <h2 className="text-base sm:text-lg font-bold text-[#101713]">1. Introduction & Overview</h2>
            <p>
              Growify Digital (“we,” “our,” or “us”), founded by Vivek Singh, respects your privacy and is committed to protecting the personal and commercial information you share with us. This Privacy Policy outlines our procedures regarding the collection, use, storage, and disclosure of data gathered via our website (growifydigital.com), contact forms, direct email communications, and WhatsApp interactions.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="text-base sm:text-lg font-bold text-[#101713]">2. Information We Collect</h2>
            <p>We may collect information you voluntarily provide to us when submitting inquiries, requesting quotations, or engaging our digital services:</p>
            <ul className="list-disc pl-5 space-y-1">
              <li><strong>Contact Information:</strong> Full name, company or brand name, email address, telephone/WhatsApp number, and geographic country.</li>
              <li><strong>Project Scope Data:</strong> Website specifications, marketing objectives, target audience details, and estimated project budgets.</li>
              <li><strong>Technical Logs:</strong> Browser user-agent, IP address, general country-level geographic location, and referring URL paths collected through standard web analytics.</li>
            </ul>
          </section>

          <section className="space-y-2">
            <h2 className="text-base sm:text-lg font-bold text-[#101713]">3. How We Use Your Information</h2>
            <p>Your information is used strictly for legitimate commercial and operational purposes:</p>
            <ul className="list-disc pl-5 space-y-1">
              <li>Formulating customized project proposals, audits, and cost estimates.</li>
              <li>Direct project correspondence via email (hello.growify@gmail.com) or WhatsApp.</li>
              <li>Managing client contracts, deliverables, milestones, and technical handovers.</li>
              <li>Optimizing website performance and search visibility.</li>
            </ul>
            <p className="font-semibold text-[#101713]">
              We do not sell, rent, lease, or monetize your personal or business data to any third-party brokers or data syndicators.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="text-base sm:text-lg font-bold text-[#101713]">4. Third-Party Analytics & Tracking</h2>
            <p>
              Our website may utilize standard analytics frameworks (such as Google Analytics 4) to monitor aggregate traffic patterns, page load times, and device viewports. These services utilize anonymous identifiers and cookies that do not directly identify individual personal identities.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="text-base sm:text-lg font-bold text-[#101713]">5. Advertising & Platform Access Credentials</h2>
            <p>
              When providing Google Ads or Meta Ads management, we strictly request delegated partner access (e.g. via Google Ads Manager Account or Meta Business Manager Partner access). Clients retain 100% ownership and direct billing custody of their advertising payment methods. Growify Digital never requests or stores raw banking passwords.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="text-base sm:text-lg font-bold text-[#101713]">6. International Data Transfers</h2>
            <p>
              As an agency serving clients across India, the United States, United Kingdom, Canada, and Australia, data may be accessed across international jurisdictions strictly for project execution purposes in compliance with applicable cross-border data protection principles.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="text-base sm:text-lg font-bold text-[#101713]">7. Contact Our Privacy Lead</h2>
            <p>
              If you have any questions or wish to request data correction or deletion, please contact us directly:
            </p>
            <div className="p-4 rounded-xl bg-neutral-50 border border-neutral-200 text-xs text-[#101713] space-y-1">
              <div><strong>Growify Digital</strong> (Founder: Vivek Singh)</div>
              <div>Email: <a href={`mailto:${COMPANY_INFO.email}`} className="text-[#16A36A] underline">{COMPANY_INFO.email}</a></div>
              <div>WhatsApp: <a href={COMPANY_INFO.whatsappUrl} className="text-[#16A36A] underline">{COMPANY_INFO.whatsappNumber}</a></div>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};
