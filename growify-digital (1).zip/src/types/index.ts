export type Currency = 'INR' | 'USD';

export interface ServiceFAQ {
  question: string;
  answer: string;
}

export interface ServiceDetail {
  id: string;
  slug: string;
  title: string;
  shortDesc: string;
  fullDesc: string;
  tagline: string;
  startingPriceINR: number;
  startingPriceUSD: number;
  billingPeriod: string; // e.g. "one-time" or "month"
  icon: string;
  accentGradient: string;
  problemsSolved: {
    title: string;
    description: string;
  }[];
  processSteps: {
    step: string;
    title: string;
    description: string;
  }[];
  keyBenefits: {
    title: string;
    description: string;
    metric?: string;
  }[];
  deliverables: string[];
  faqs: ServiceFAQ[];
  metaTitle: string;
  metaDesc: string;
  targetKeywords: string[];
}

export interface PortfolioItem {
  id: string;
  title: string;
  category: string;
  description: string;
  image: string;
  tags: string[];
  metrics: {
    label: string;
    value: string;
  }[];
  isDemoPlaceholder: boolean;
}

export interface ContactFormData {
  fullName: string;
  businessName: string;
  email: string;
  country: string;
  serviceRequired: string;
  estimatedBudget: string;
  projectDetails: string;
}
