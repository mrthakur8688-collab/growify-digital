import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { ChevronDown, Menu, X, ArrowUpRight, Globe, Layers, Search, MapPin, Target, Megaphone } from 'lucide-react';
import { useCurrency } from '../../context/CurrencyContext';
import { COMPANY_INFO } from '../../data/companyData';
import { SERVICES } from '../../data/servicesData';

const SERVICE_ICONS: Record<string, React.ElementType> = {
  'web-development': Globe,
  'ui-ux-design': Layers,
  'seo': Search,
  'local-seo': MapPin,
  'google-ads': Target,
  'meta-ads': Megaphone,
};

export const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isServicesOpen, setIsServicesOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();
  const { currency, setCurrency } = useCurrency();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close dropdowns on route change
  useEffect(() => {
    setIsServicesOpen(false);
    setIsMobileMenuOpen(false);
  }, [location.pathname]);

  const navLinks = [
    { label: 'Home', href: '/' },
    { label: 'About', href: '/about' },
    { label: 'Pricing', href: '/pricing' },
    { label: 'Contact', href: '/contact' },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-white/95 backdrop-blur-md shadow-sm border-b border-neutral-100 py-3.5'
          : 'bg-white/80 backdrop-blur-sm border-b border-neutral-100/60 py-4'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-6">
          {/* Zone 1: Single Brand Wordmark & Logo */}
          <Link
            to="/"
            className="flex items-center gap-3 shrink-0 group focus:outline-none focus-visible:ring-2 focus-visible:ring-[#16A36A] rounded-lg"
            aria-label="Growify Digital Home"
          >
            <img
              src={COMPANY_INFO.logoUrl}
              alt="Growify Digital Logo"
              className="w-9 h-9 sm:w-10 sm:h-10 rounded-lg object-contain border border-neutral-100 shadow-2xs group-hover:scale-102 transition-transform duration-200"
            />
            <span className="text-xl font-bold tracking-tight text-[#101713] whitespace-nowrap">
              Growify<span className="text-[#16A36A]">.</span>
            </span>
          </Link>

          {/* Zone 2: Navigation Links (Desktop) */}
          <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-[#68736C]">
            <Link
              to="/"
              className={`hover:text-[#101713] transition-colors whitespace-nowrap ${
                location.pathname === '/' ? 'text-[#16A36A] font-semibold' : ''
              }`}
            >
              Home
            </Link>
            <Link
              to="/about"
              className={`hover:text-[#101713] transition-colors whitespace-nowrap ${
                location.pathname === '/about' ? 'text-[#16A36A] font-semibold' : ''
              }`}
            >
              About
            </Link>

            {/* Services Dropdown */}
            <div
              className="relative"
              onMouseEnter={() => setIsServicesOpen(true)}
              onMouseLeave={() => setIsServicesOpen(false)}
            >
              <button
                type="button"
                className={`flex items-center gap-1.5 hover:text-[#101713] transition-colors whitespace-nowrap py-1 ${
                  location.pathname.startsWith('/services') ? 'text-[#16A36A] font-semibold' : ''
                }`}
                onClick={() => setIsServicesOpen((prev) => !prev)}
                aria-expanded={isServicesOpen}
              >
                <span>Services</span>
                <ChevronDown
                  className={`w-3.5 h-3.5 transition-transform duration-200 ${
                    isServicesOpen ? 'rotate-180 text-[#16A36A]' : ''
                  }`}
                />
              </button>

              {/* Mega Dropdown Menu */}
              {isServicesOpen && (
                <div className="absolute top-full left-1/2 -translate-x-1/2 pt-2 w-[540px] z-50">
                  <div className="bg-white rounded-2xl shadow-xl border border-neutral-100 p-4 grid grid-cols-2 gap-2 animate-in fade-in slide-in-from-top-2 duration-150">
                    {SERVICES.map((s) => {
                      const Icon = SERVICE_ICONS[s.id] || Globe;
                      const isActive = location.pathname === `/services/${s.slug}`;
                      return (
                        <Link
                          key={s.id}
                          to={`/services/${s.slug}`}
                          className={`flex items-start gap-3 p-3 rounded-xl transition-all ${
                            isActive
                              ? 'bg-[#EAF8F0] text-[#075B3B]'
                              : 'hover:bg-neutral-50 text-[#101713]'
                          }`}
                        >
                          <div className="w-8 h-8 rounded-lg bg-[#EAF8F0] text-[#16A36A] flex items-center justify-center shrink-0 mt-0.5">
                            <Icon className="w-4 h-4" />
                          </div>
                          <div>
                            <div className="text-xs font-bold leading-tight flex items-center gap-1">
                              {s.title}
                              <ArrowUpRight className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                            </div>
                            <div className="text-[11px] text-[#68736C] line-clamp-1 mt-0.5">
                              {s.tagline}
                            </div>
                          </div>
                        </Link>
                      );
                    })}
                    <div className="col-span-2 pt-2 border-t border-neutral-100 mt-1 flex items-center justify-between px-2 text-xs text-[#68736C]">
                      <span>6 International Growth Capabilities</span>
                      <Link
                        to="/services"
                        className="text-[#16A36A] font-semibold hover:underline inline-flex items-center gap-1"
                      >
                        View All Services &rarr;
                      </Link>
                    </div>
                  </div>
                </div>
              )}
            </div>

            <Link
              to="/pricing"
              className={`hover:text-[#101713] transition-colors whitespace-nowrap ${
                location.pathname === '/pricing' ? 'text-[#16A36A] font-semibold' : ''
              }`}
            >
              Pricing
            </Link>
            <Link
              to="/contact"
              className={`hover:text-[#101713] transition-colors whitespace-nowrap ${
                location.pathname === '/contact' ? 'text-[#16A36A] font-semibold' : ''
              }`}
            >
              Contact
            </Link>
          </nav>

          {/* Zone 3: Currency Switcher & Primary Action */}
          <div className="flex items-center gap-3 shrink-0">
            {/* Currency Selector */}
            <div
              className="flex items-center p-0.5 bg-neutral-100 rounded-lg text-xs font-medium"
              role="group"
              aria-label="Currency Selector"
            >
              <button
                type="button"
                onClick={() => setCurrency('INR')}
                className={`px-2.5 py-1 rounded-md transition-all whitespace-nowrap ${
                  currency === 'INR'
                    ? 'bg-white text-[#075B3B] font-semibold shadow-2xs'
                    : 'text-[#68736C] hover:text-[#101713]'
                }`}
                title="View pricing in Indian Rupees (INR)"
              >
                ₹ INR
              </button>
              <button
                type="button"
                onClick={() => setCurrency('USD')}
                className={`px-2.5 py-1 rounded-md transition-all whitespace-nowrap ${
                  currency === 'USD'
                    ? 'bg-white text-[#075B3B] font-semibold shadow-2xs'
                    : 'text-[#68736C] hover:text-[#101713]'
                }`}
                title="View pricing in US Dollars (USD - International)"
              >
                $ USD
              </button>
            </div>

            {/* Primary Action Button */}
            <Link
              to="/contact"
              className="hidden sm:inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-[#16A36A] hover:bg-[#075B3B] rounded-lg transition-colors shadow-sm whitespace-nowrap focus:outline-none focus-visible:ring-2 focus-visible:ring-[#16A36A] focus-visible:ring-offset-2"
            >
              <span>Get Custom Quote</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </Link>

            {/* Mobile Menu Button */}
            <button
              type="button"
              onClick={() => setIsMobileMenuOpen((prev) => !prev)}
              className="md:hidden p-2 text-[#101713] hover:text-[#16A36A] rounded-lg focus:outline-none"
              aria-label={isMobileMenuOpen ? 'Close Menu' : 'Open Menu'}
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-white border-b border-neutral-200 px-4 pt-3 pb-6 max-h-[85vh] overflow-y-auto animate-in slide-in-from-top-4 duration-200">
          <div className="flex flex-col space-y-1">
            <Link
              to="/"
              className="px-3 py-2.5 text-base font-semibold text-[#101713] hover:bg-[#EAF8F0] rounded-lg"
            >
              Home
            </Link>
            <Link
              to="/about"
              className="px-3 py-2.5 text-base font-semibold text-[#101713] hover:bg-[#EAF8F0] rounded-lg"
            >
              About Us
            </Link>

            <div className="pt-2 pb-1">
              <div className="px-3 text-xs font-bold uppercase tracking-wider text-[#68736C] mb-2">
                Our Services
              </div>
              <div className="space-y-1 pl-2">
                {SERVICES.map((s) => (
                  <Link
                    key={s.id}
                    to={`/services/${s.slug}`}
                    className="block px-3 py-2 text-sm text-[#101713] hover:text-[#16A36A] hover:bg-[#EAF8F0] rounded-lg"
                  >
                    {s.title}
                  </Link>
                ))}
              </div>
            </div>

            <Link
              to="/pricing"
              className="px-3 py-2.5 text-base font-semibold text-[#101713] hover:bg-[#EAF8F0] rounded-lg"
            >
              Pricing
            </Link>
            <Link
              to="/contact"
              className="px-3 py-2.5 text-base font-semibold text-[#101713] hover:bg-[#EAF8F0] rounded-lg"
            >
              Contact Us
            </Link>

            <div className="pt-4 border-t border-neutral-100 flex flex-col gap-3">
              <div className="flex items-center justify-between px-2 text-xs text-[#68736C]">
                <span>Active Currency:</span>
                <span className="font-bold text-[#101713]">
                  {currency === 'INR' ? '₹ INR (India)' : '$ USD (International)'}
                </span>
              </div>
              <Link
                to="/contact"
                className="w-full text-center py-3 text-sm font-semibold text-white bg-[#16A36A] hover:bg-[#075B3B] rounded-lg transition-colors shadow-sm"
              >
                Get Custom Quote &rarr;
              </Link>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
