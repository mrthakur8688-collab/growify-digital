import React from 'react';
import { Link } from 'react-router-dom';
import { Mail, MessageCircle, Instagram, Facebook, Linkedin, ArrowUpRight, ShieldCheck } from 'lucide-react';
import { COMPANY_INFO } from '../../data/companyData';
import { SERVICES } from '../../data/servicesData';
import { useCurrency } from '../../context/CurrencyContext';

export const Footer: React.FC = () => {
  const { currency, setCurrency } = useCurrency();

  return (
    <footer className="bg-[#101713] text-white pt-16 pb-12 border-t border-neutral-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-neutral-800">
          {/* Brand & Mission Column */}
          <div className="lg:col-span-2 space-y-4">
            <Link to="/" className="flex items-center gap-3 inline-flex">
              <img
                src={COMPANY_INFO.logoUrl}
                alt="Growify Digital"
                className="w-10 h-10 rounded-lg object-contain bg-white p-0.5"
              />
              <span className="text-2xl font-bold tracking-tight text-white">
                Growify<span className="text-[#16A36A]">.</span>
              </span>
            </Link>
            <p className="text-sm text-neutral-400 max-w-sm leading-relaxed">
              Growify Digital is a premium international digital growth agency. We build
              conversion-engineered web applications, implement high-intent SEO, and scale Google &
              Meta advertising campaigns for ambitious brands across India and global markets.
            </p>
            <div className="pt-2">
              <div className="text-xs uppercase tracking-wider text-neutral-500 font-semibold mb-2">
                Target Markets
              </div>
              <div className="flex flex-wrap items-center gap-2 text-xs text-neutral-300">
                {COMPANY_INFO.targetMarkets.map((m) => (
                  <span
                    key={m.country}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-neutral-900 border border-neutral-800"
                  >
                    <span>{m.flag}</span>
                    <span>{m.country}</span>
                  </span>
                ))}
              </div>
            </div>

            {/* Currency selector inside footer */}
            <div className="pt-3 flex items-center gap-2 text-xs text-neutral-400">
              <span>Currency:</span>
              <button
                type="button"
                onClick={() => setCurrency('INR')}
                className={`px-2 py-0.5 rounded transition-colors ${
                  currency === 'INR' ? 'bg-[#16A36A] text-white font-bold' : 'hover:text-white'
                }`}
              >
                ₹ INR (India)
              </button>
              <span>·</span>
              <button
                type="button"
                onClick={() => setCurrency('USD')}
                className={`px-2 py-0.5 rounded transition-colors ${
                  currency === 'USD' ? 'bg-[#16A36A] text-white font-bold' : 'hover:text-white'
                }`}
              >
                $ USD (International)
              </button>
            </div>
          </div>

          {/* 6 Services Column */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-400">
              Services
            </h3>
            <ul className="space-y-2 text-sm text-neutral-300">
              {SERVICES.map((s) => (
                <li key={s.id}>
                  <Link
                    to={`/services/${s.slug}`}
                    className="hover:text-[#16A36A] transition-colors inline-flex items-center gap-1"
                  >
                    <span>{s.title}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Quick Navigation Column */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-400">
              Company
            </h3>
            <ul className="space-y-2 text-sm text-neutral-300">
              <li>
                <Link to="/" className="hover:text-[#16A36A] transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/about" className="hover:text-[#16A36A] transition-colors">
                  About Us (Founder Story)
                </Link>
              </li>
              <li>
                <Link to="/services" className="hover:text-[#16A36A] transition-colors">
                  Our Services
                </Link>
              </li>
              <li>
                <Link to="/pricing" className="hover:text-[#16A36A] transition-colors">
                  International Pricing
                </Link>
              </li>
              <li>
                <Link to="/contact" className="hover:text-[#16A36A] transition-colors">
                  Contact & Inquiries
                </Link>
              </li>
              <li>
                <Link to="/privacy" className="hover:text-[#16A36A] transition-colors">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link to="/terms" className="hover:text-[#16A36A] transition-colors">
                  Terms & Conditions
                </Link>
              </li>
            </ul>
          </div>

          {/* Official Contact & Socials */}
          <div className="space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-400">
              Direct Contact
            </h3>
            <div className="space-y-2.5 text-sm text-neutral-300">
              <a
                href={`mailto:${COMPANY_INFO.email}`}
                className="flex items-center gap-2 hover:text-[#16A36A] transition-colors group"
              >
                <div className="w-8 h-8 rounded-lg bg-neutral-900 flex items-center justify-center text-[#16A36A] group-hover:bg-[#16A36A] group-hover:text-white transition-colors shrink-0">
                  <Mail className="w-4 h-4" />
                </div>
                <span className="text-xs break-all">{COMPANY_INFO.email}</span>
              </a>

              <a
                href={COMPANY_INFO.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 hover:text-[#16A36A] transition-colors group"
                aria-label="Direct WhatsApp Message"
              >
                <div className="w-8 h-8 rounded-lg bg-neutral-900 flex items-center justify-center text-[#16A36A] group-hover:bg-[#16A36A] group-hover:text-white transition-colors shrink-0">
                  <MessageCircle className="w-4 h-4" />
                </div>
                <span className="text-xs font-medium">{COMPANY_INFO.whatsappNumber}</span>
              </a>
            </div>

            <div className="pt-2">
              <div className="text-xs font-bold uppercase tracking-wider text-neutral-400 mb-2.5">
                Official Social Profiles
              </div>
              <div className="flex items-center gap-3">
                <a
                  href={COMPANY_INFO.socials.instagram}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-9 h-9 rounded-lg bg-neutral-900 hover:bg-[#16A36A] text-neutral-300 hover:text-white flex items-center justify-center transition-colors focus:outline-none focus:ring-2 focus:ring-[#16A36A]"
                  aria-label="Growify Digital Instagram"
                >
                  <Instagram className="w-4 h-4" />
                </a>
                <a
                  href={COMPANY_INFO.socials.facebook}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-9 h-9 rounded-lg bg-neutral-900 hover:bg-[#16A36A] text-neutral-300 hover:text-white flex items-center justify-center transition-colors focus:outline-none focus:ring-2 focus:ring-[#16A36A]"
                  aria-label="Growify Digital Facebook"
                >
                  <Facebook className="w-4 h-4" />
                </a>
                <a
                  href={COMPANY_INFO.socials.linkedin}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-9 h-9 rounded-lg bg-neutral-900 hover:bg-[#16A36A] text-neutral-300 hover:text-white flex items-center justify-center transition-colors focus:outline-none focus:ring-2 focus:ring-[#16A36A]"
                  aria-label="Vivek Singh LinkedIn"
                >
                  <Linkedin className="w-4 h-4" />
                </a>
              </div>
            </div>

            <div className="pt-2">
              <a
                href={COMPANY_INFO.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-3 py-2 text-xs font-semibold text-[#075B3B] bg-[#EAF8F0] hover:bg-white rounded-lg transition-colors"
              >
                <span>Instant WhatsApp Chat</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        </div>

        {/* Bottom Disclaimer & Copyright */}
        <div className="pt-8 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-neutral-400">
          <div>
            &copy; {new Date().getFullYear()} Growify Digital. Founded by Vivek Singh. All rights
            reserved.
          </div>
          <div className="flex items-center gap-4">
            <Link to="/privacy" className="hover:text-white transition-colors">
              Privacy Policy
            </Link>
            <span>·</span>
            <Link to="/terms" className="hover:text-white transition-colors">
              Terms & Conditions
            </Link>
            <span>·</span>
            <span className="text-neutral-500">Cloudflare Pages Ready</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
