import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, MessageCircle, CheckCircle2, ChevronRight, ShieldCheck, AlertCircle, HelpCircle } from 'lucide-react';
import { ServiceDetail } from '../../types';
import { COMPANY_INFO } from '../../data/companyData';
import { useCurrency } from '../../context/CurrencyContext';
import { FAQAccordion } from '../common/FAQAccordion';
import { SEOHead } from '../common/SEOHead';

interface ServiceDetailTemplateProps {
  service: ServiceDetail;
}

export const ServiceDetailTemplate: React.FC<ServiceDetailTemplateProps> = ({ service }) => {
  const { currency, setCurrency, formatStartingPrice } = useCurrency();

  const formattedPrice = formatStartingPrice(
    service.startingPriceINR,
    service.startingPriceUSD,
    service.billingPeriod
  );

  const serviceSchema = {
    '@context': 'https://schema.org',
    '@type': 'Service',
    serviceType: service.title,
    provider: {
      '@type': 'Organization',
      name: 'Growify Digital',
      url: 'https://growifydigital.com',
      telephone: '+919302584559',
      founder: {
        '@type': 'Person',
        name: 'Vivek Singh',
      },
    },
    description: service.shortDesc,
    offers: {
      '@type': 'Offer',
      price: currency === 'INR' ? service.startingPriceINR : service.startingPriceUSD,
      priceCurrency: currency,
      priceSpecification: {
        '@type': 'UnitPriceSpecification',
        price: currency === 'INR' ? service.startingPriceINR : service.startingPriceUSD,
        priceCurrency: currency,
        unitText: service.billingPeriod,
      },
    },
    areaServed: ['India', 'United States', 'United Kingdom', 'Canada', 'Australia'],
  };

  return (
    <div className="pt-24 pb-20">
      <SEOHead
        title={service.metaTitle}
        description={service.metaDesc}
        canonicalPath={`/services/${service.slug}`}
        keywords={service.targetKeywords}
        schemaJson={serviceSchema}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Breadcrumb Navigation */}
        <nav className="flex items-center gap-2 text-xs text-[#68736C] mb-8" aria-label="Breadcrumb">
          <Link to="/" className="hover:text-[#101713] transition-colors">
            Home
          </Link>
          <ChevronRight className="w-3.5 h-3.5" />
          <Link to="/services" className="hover:text-[#101713] transition-colors">
            Services
          </Link>
          <ChevronRight className="w-3.5 h-3.5" />
          <span className="text-[#101713] font-semibold">{service.title}</span>
        </nav>

        {/* Hero Section */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start pb-16 border-b border-neutral-100">
          <div className="lg:col-span-8 space-y-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-[#EAF8F0] text-[#075B3B] text-xs font-semibold">
              <span>Growify Service Suite</span>
              <span>·</span>
              <span>International Delivery</span>
            </div>

            <h1 className="text-3xl sm:text-5xl font-bold tracking-tight text-[#101713] leading-tight">
              {service.title}
            </h1>

            <p className="text-lg sm:text-xl font-medium text-[#16A36A]">
              {service.tagline}
            </p>

            <p className="text-base text-[#68736C] leading-relaxed max-w-3xl">
              {service.fullDesc}
            </p>

            {/* CTAs */}
            <div className="pt-4 flex flex-wrap items-center gap-4">
              <Link
                to={`/contact?service=${service.slug}`}
                className="px-6 py-3.5 rounded-xl font-semibold text-xs text-white bg-[#16A36A] hover:bg-[#075B3B] transition-colors shadow-sm flex items-center gap-2"
              >
                <span>Request Custom Quotation</span>
                <ArrowRight className="w-4 h-4" />
              </Link>

              <a
                href={`https://wa.me/${COMPANY_INFO.whatsappRaw}?text=Hello%20Growify%20Digital!%20I%E2%80%99m%20interested%20in%20your%20${encodeURIComponent(
                  service.title
                )}%20service.%20I%E2%80%99d%20like%20to%20discuss%20my%20business%20requirements%20and%20get%20a%20customized%20proposal.`}
                target="_blank"
                rel="noopener noreferrer"
                className="px-6 py-3.5 rounded-xl font-semibold text-xs text-[#075B3B] bg-[#EAF8F0] hover:bg-[#16A36A] hover:text-white transition-colors flex items-center gap-2 border border-[#16A36A]/20"
              >
                <MessageCircle className="w-4 h-4" />
                <span>WhatsApp Enquiry</span>
              </a>
            </div>
          </div>

          {/* Pricing Box Sticky Aside */}
          <div className="lg:col-span-4 p-6 sm:p-8 rounded-3xl bg-neutral-50 border border-neutral-200/90 shadow-sm space-y-6">
            <div className="flex items-center justify-between">
              <div className="text-xs font-bold uppercase tracking-wider text-[#68736C]">
                Investment Guide
              </div>
              <div className="flex items-center gap-1 p-0.5 bg-white rounded-lg border border-neutral-200 text-[11px] font-semibold">
                <button
                  type="button"
                  onClick={() => setCurrency('INR')}
                  className={`px-2 py-0.5 rounded ${currency === 'INR' ? 'bg-[#16A36A] text-white' : 'text-[#68736C]'}`}
                >
                  ₹ INR
                </button>
                <button
                  type="button"
                  onClick={() => setCurrency('USD')}
                  className={`px-2 py-0.5 rounded ${currency === 'USD' ? 'bg-[#16A36A] text-white' : 'text-[#68736C]'}`}
                >
                  $ USD
                </button>
              </div>
            </div>

            <div>
              <div className="text-xs font-semibold text-[#68736C] uppercase tracking-wider">
                Starting From
              </div>
              <div className="mt-1 text-3xl font-bold text-[#101713]">
                {currency === 'INR' ? '₹' : '$'}
                {currency === 'INR'
                  ? service.startingPriceINR.toLocaleString('en-IN')
                  : service.startingPriceUSD.toLocaleString('en-US')}
                {service.billingPeriod === 'month' && (
                  <span className="text-xs font-normal text-[#68736C]">/month</span>
                )}
              </div>
              <p className="mt-2 text-xs text-[#68736C] leading-relaxed italic">
                *Estimated baseline. Final proposal depends on exact scope, deliverables, and complexity.
              </p>
            </div>

            <div className="space-y-3 pt-4 border-t border-neutral-200/80 text-xs">
              <div className="flex items-center gap-2 text-[#101713] font-semibold">
                <ShieldCheck className="w-4 h-4 text-[#16A36A]" />
                <span>Founder-Led Strategic Review</span>
              </div>
              <div className="flex items-center gap-2 text-[#101713] font-semibold">
                <CheckCircle2 className="w-4 h-4 text-[#16A36A]" />
                <span>Multi-Market Experience (IN, US, UK, CA, AU)</span>
              </div>
              <div className="flex items-center gap-2 text-[#101713] font-semibold">
                <CheckCircle2 className="w-4 h-4 text-[#16A36A]" />
                <span>Transparent Milestone Tracking</span>
              </div>
            </div>

            <Link
              to={`/contact?service=${service.slug}`}
              className="w-full text-center block py-3 px-4 rounded-xl text-xs font-bold text-white bg-[#16A36A] hover:bg-[#075B3B] transition-colors shadow-2xs"
            >
              Get Custom Proposal &rarr;
            </Link>
          </div>
        </div>

        {/* Section 1: Business Problems We Solve */}
        <div className="py-16 border-b border-neutral-100">
          <div className="max-w-2xl mb-12">
            <div className="text-xs font-bold uppercase tracking-wider text-[#16A36A] mb-2">
              Diagnostic Clarity
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold text-[#101713]">
              Critical Business Bottlenecks We Solve
            </h2>
            <p className="mt-2 text-sm text-[#68736C]">
              Ambitious brands lose thousands in unrealized revenue when digital touchpoints break down. Here is how we resolve these bottlenecks.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {service.problemsSolved.map((prob, idx) => (
              <div
                key={idx}
                className="p-6 rounded-2xl bg-white border border-neutral-200/80 hover:border-[#16A36A]/50 transition-colors shadow-2xs space-y-2"
              >
                <div className="flex items-center gap-2 text-sm font-bold text-[#101713]">
                  <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                  <span>{prob.title}</span>
                </div>
                <p className="text-xs sm:text-sm text-[#68736C] leading-relaxed pl-6">
                  {prob.description}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Section 2: Our 5-Step Working Process */}
        <div className="py-16 border-b border-neutral-100">
          <div className="max-w-2xl mb-12">
            <div className="text-xs font-bold uppercase tracking-wider text-[#16A36A] mb-2">
              Methodical Execution
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold text-[#101713]">
              Our Working Process
            </h2>
            <p className="mt-2 text-sm text-[#68736C]">
              We adhere to a proven 5-stage framework that replaces guesswork with measurable execution.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            {service.processSteps.map((step) => (
              <div
                key={step.step}
                className="p-5 rounded-2xl bg-neutral-50/70 border border-neutral-200 flex flex-col justify-between"
              >
                <div>
                  <div className="text-xl font-bold text-[#16A36A] mb-2">{step.step}</div>
                  <h3 className="text-sm font-bold text-[#101713] mb-2">{step.title}</h3>
                  <p className="text-xs text-[#68736C] leading-relaxed">{step.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Section 3: Key Strategic Benefits */}
        <div className="py-16 border-b border-neutral-100">
          <div className="max-w-2xl mb-12">
            <div className="text-xs font-bold uppercase tracking-wider text-[#16A36A] mb-2">
              Strategic Advantages
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold text-[#101713]">
              Measurable Key Benefits
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {service.keyBenefits.map((b, idx) => (
              <div
                key={idx}
                className="p-6 rounded-2xl bg-white border border-neutral-200 flex flex-col justify-between space-y-4"
              >
                <div className="space-y-2">
                  <div className="text-xs font-bold text-[#16A36A] uppercase tracking-wider">
                    {b.metric}
                  </div>
                  <h3 className="text-base font-bold text-[#101713]">{b.title}</h3>
                  <p className="text-xs text-[#68736C] leading-relaxed">{b.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Section 4: Deliverables Checklist */}
        <div className="py-16 border-b border-neutral-100">
          <div className="max-w-2xl mb-8">
            <div className="text-xs font-bold uppercase tracking-wider text-[#16A36A] mb-2">
              Concrete Scope
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold text-[#101713]">
              What You Receive (Deliverables)
            </h2>
            <p className="mt-2 text-sm text-[#68736C]">
              Every client engagement delivers tangible, high-value assets and clear accountability.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {service.deliverables.map((item, idx) => (
              <div
                key={idx}
                className="flex items-start gap-3 p-4 rounded-xl bg-neutral-50/80 border border-neutral-200/70 text-xs sm:text-sm text-[#101713]"
              >
                <CheckCircle2 className="w-5 h-5 text-[#16A36A] shrink-0 mt-0.5" />
                <span className="font-medium">{item}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Section 5: Relevant FAQs */}
        <div className="py-16 border-b border-neutral-100">
          <div className="max-w-2xl mb-10">
            <div className="text-xs font-bold uppercase tracking-wider text-[#16A36A] mb-2">
              Frequently Asked Questions
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold text-[#101713]">
              Got Questions About {service.title}?
            </h2>
          </div>

          <div className="max-w-3xl">
            <FAQAccordion faqs={service.faqs} includeSchema={true} />
          </div>
        </div>

        {/* Section 6: Final Conversion CTA */}
        <div className="mt-16 p-8 sm:p-12 rounded-3xl bg-radial from-[#075B3B] to-[#101713] text-white flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="max-w-xl space-y-2">
            <h3 className="text-2xl sm:text-3xl font-bold tracking-tight">
              Ready to Accelerate Your {service.title}?
            </h3>
            <p className="text-sm text-neutral-300 leading-relaxed">
              Let’s discuss your current benchmarks, project timeline, and commercial goals. Request a customized proposal or chat instantly with Vivek Singh.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-3 shrink-0 w-full md:w-auto">
            <Link
              to={`/contact?service=${service.slug}`}
              className="w-full sm:w-auto text-center px-6 py-3.5 rounded-xl font-bold text-xs text-[#075B3B] bg-white hover:bg-neutral-100 transition-colors shadow-md"
            >
              Get Custom Quote
            </Link>

            <a
              href={`https://wa.me/${COMPANY_INFO.whatsappRaw}?text=Hello%20Growify%20Digital!%20I%E2%80%99m%20interested%20in%20your%20${encodeURIComponent(
                service.title
              )}%20service.`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto text-center px-6 py-3.5 rounded-xl font-bold text-xs text-white bg-[#16A36A] hover:bg-emerald-700 transition-colors flex items-center justify-center gap-2"
            >
              <MessageCircle className="w-4 h-4" />
              <span>WhatsApp Chat</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
