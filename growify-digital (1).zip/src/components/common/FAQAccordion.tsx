import React, { useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { ServiceFAQ } from '../../types';

interface FAQAccordionProps {
  faqs: ServiceFAQ[];
  includeSchema?: boolean;
}

export const FAQAccordion: React.FC<FAQAccordionProps> = ({ faqs, includeSchema = true }) => {
  const [openIndices, setOpenIndices] = useState<number[]>([0]);

  const toggleFAQ = (index: number) => {
    setOpenIndices((prev) =>
      prev.includes(index) ? prev.filter((i) => i !== index) : [...prev, index]
    );
  };

  const faqSchema = includeSchema
    ? {
        '@context': 'https://schema.org',
        '@type': 'FAQPage',
        mainEntity: faqs.map((f) => ({
          '@type': 'Question',
          name: f.question,
          acceptedAnswer: {
            '@type': 'Answer',
            text: f.answer,
          },
        })),
      }
    : null;

  return (
    <div className="w-full space-y-4">
      {faqSchema && (
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}
        />
      )}

      {faqs.map((faq, index) => {
        const isOpen = openIndices.includes(index);
        return (
          <div
            key={index}
            className="rounded-2xl border border-neutral-200 bg-white overflow-hidden transition-all duration-200"
          >
            <button
              type="button"
              onClick={() => toggleFAQ(index)}
              className="w-full p-5 sm:p-6 text-left flex items-center justify-between gap-4 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#16A36A]"
              aria-expanded={isOpen}
            >
              <span className="text-sm sm:text-base font-bold text-[#101713]">
                {faq.question}
              </span>
              <div
                className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 transition-transform duration-200 ${
                  isOpen ? 'bg-[#EAF8F0] text-[#16A36A] rotate-180' : 'bg-neutral-100 text-[#68736C]'
                }`}
              >
                <ChevronDown className="w-4 h-4" />
              </div>
            </button>

            {isOpen && (
              <div className="px-5 sm:px-6 pb-6 pt-1 text-xs sm:text-sm text-[#68736C] leading-relaxed border-t border-neutral-50 animate-in fade-in duration-150">
                {faq.answer}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
};
