import React, { useState, useRef } from 'react';
import { Linkedin, MessageCircle, Mail, Camera, RefreshCw, CheckCircle2 } from 'lucide-react';
import { COMPANY_INFO } from '../../data/companyData';

export const FounderSection: React.FC = () => {
  const [photoUrl, setPhotoUrl] = useState<string>(() => {
    return localStorage.getItem('growify_founder_photo') || COMPANY_INFO.founder.photoUrl;
  });
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setIsUploading(true);
      const reader = new FileReader();
      reader.onload = (event) => {
        const result = event.target?.result as string;
        setPhotoUrl(result);
        localStorage.setItem('growify_founder_photo', result);
        setIsUploading(false);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleResetPhoto = () => {
    setPhotoUrl(COMPANY_INFO.founder.photoUrl);
    localStorage.removeItem('growify_founder_photo');
  };

  return (
    <section className="py-20 bg-neutral-50/60 border-y border-neutral-100" id="founder">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="text-xs font-bold uppercase tracking-wider text-[#16A36A] mb-2">
            Leadership & Vision
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-[#101713]">
            Meet Our Founder
          </h2>
          <p className="mt-3 text-base text-[#68736C]">
            Strategic leadership dedicated to helping ambitious businesses scale with international
            digital standards.
          </p>
        </div>

        {/* Editorial 2-Column Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Column 1: Founder Photograph with dedicated upload control */}
          <div className="lg:col-span-5 flex flex-col items-center">
            <div className="relative group w-full max-w-md">
              <div className="relative aspect-4/5 rounded-3xl overflow-hidden shadow-2xl border-4 border-white bg-neutral-100">
                <img
                  src={photoUrl}
                  alt="Vivek Singh — Founder, Growify Digital"
                  className="w-full h-full object-cover object-top transition-transform duration-500 group-hover:scale-102"
                />
                
                {/* Subtle scrim at bottom */}
                <div className="absolute inset-x-0 bottom-0 p-6 bg-gradient-to-t from-black/85 via-black/40 to-transparent text-white">
                  <div className="text-xl font-bold">{COMPANY_INFO.founder.name}</div>
                  <div className="text-sm text-emerald-300 font-medium">{COMPANY_INFO.founder.title}</div>
                </div>
              </div>

              {/* Photo customization badge & upload control */}
              <div className="mt-4 flex items-center justify-between text-xs text-[#68736C] px-2">
                <span className="inline-flex items-center gap-1.5 font-medium text-[#101713]">
                  <CheckCircle2 className="w-4 h-4 text-[#16A36A]" />
                  <span>Real Founder Photo</span>
                </span>
                
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="inline-flex items-center gap-1 text-xs text-[#16A36A] hover:text-[#075B3B] font-semibold hover:underline"
                    title="Upload or change founder photo"
                  >
                    <Camera className="w-3.5 h-3.5" />
                    <span>Upload New Photo</span>
                  </button>
                  {photoUrl !== COMPANY_INFO.founder.photoUrl && (
                    <button
                      type="button"
                      onClick={handleResetPhoto}
                      className="inline-flex items-center gap-1 text-xs text-neutral-400 hover:text-neutral-700"
                      title="Reset to official photograph"
                    >
                      <RefreshCw className="w-3 h-3" />
                      <span>Reset</span>
                    </button>
                  )}
                </div>
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  accept="image/*"
                  className="hidden"
                  aria-label="Upload founder photograph"
                />
              </div>
            </div>
          </div>

          {/* Column 2: Founder Editorial Profile */}
          <div className="lg:col-span-7 space-y-8">
            {/* Lead Blockquote */}
            <div className="relative pl-6 border-l-2 border-[#16A36A]">
              <blockquote className="text-xl sm:text-2xl font-medium text-[#101713] leading-relaxed italic">
                “{COMPANY_INFO.founder.introduction}”
              </blockquote>
              <div className="mt-3 text-sm font-semibold text-[#16A36A]">
                — Vivek Singh, Founder
              </div>
            </div>

            {/* Vision & Mission Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-2">
              <div className="p-6 rounded-2xl bg-white border border-neutral-200/80 shadow-xs space-y-2">
                <h3 className="text-base font-bold text-[#101713] flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-[#16A36A]"></span>
                  Personal Vision
                </h3>
                <p className="text-xs text-[#68736C] leading-relaxed">
                  {COMPANY_INFO.founder.personalVision}
                </p>
              </div>

              <div className="p-6 rounded-2xl bg-white border border-neutral-200/80 shadow-xs space-y-2">
                <h3 className="text-base font-bold text-[#101713] flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-[#16A36A]"></span>
                  Mission & Philosophy
                </h3>
                <p className="text-xs text-[#68736C] leading-relaxed">
                  {COMPANY_INFO.founder.philosophy}
                </p>
              </div>
            </div>

            {/* Message to Clients */}
            <div className="p-6 rounded-2xl bg-[#EAF8F0]/70 border border-[#16A36A]/20 space-y-2">
              <h3 className="text-sm font-bold text-[#075B3B]">
                A Message to Prospective Clients
              </h3>
              <p className="text-xs text-[#101713] leading-relaxed">
                {COMPANY_INFO.founder.messageToClients}
              </p>
            </div>

            {/* Founder Actions & Social Channels */}
            <div className="flex flex-wrap items-center gap-4 pt-2">
              <a
                href={COMPANY_INFO.founder.linkedin}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white border border-neutral-200 hover:border-[#16A36A] text-[#101713] hover:text-[#16A36A] text-xs font-semibold shadow-2xs transition-colors"
                aria-label="Connect with Vivek Singh on LinkedIn"
              >
                <Linkedin className="w-4 h-4 text-[#0077B5]" />
                <span>Connect on LinkedIn</span>
              </a>

              <a
                href={COMPANY_INFO.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#16A36A] hover:bg-[#075B3B] text-white text-xs font-semibold shadow-xs transition-colors"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Message on WhatsApp</span>
              </a>

              <a
                href={`mailto:${COMPANY_INFO.email}?subject=Inquiry%20for%20Vivek%20Singh%20-%20Growify%20Digital`}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white border border-neutral-200 hover:border-neutral-300 text-[#68736C] hover:text-[#101713] text-xs font-semibold transition-colors"
              >
                <Mail className="w-4 h-4" />
                <span>Direct Email</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
