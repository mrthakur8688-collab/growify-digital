import React from 'react';
import { SAMPLE_TESTIMONIALS } from '../../data/testimonialsData';
import { Quote, ShieldCheck, Sparkles } from 'lucide-react';

export const TestimonialsSection: React.FC = () => {
  return (
    <div className="w-full">
      <div className="text-center max-w-2xl mx-auto mb-12">
        <div className="text-xs font-bold uppercase tracking-wider text-[#16A36A] mb-2">
          Demonstration Framework
        </div>
        <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-[#101713]">
          Client Feedback Format
        </h2>
        <p className="mt-3 text-sm text-[#68736C]">
          The following cards represent the standardized evaluation and testimonial structure for upcoming verified client reviews.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {SAMPLE_TESTIMONIALS.map((t) => (
          <div
            key={t.id}
            className="p-8 rounded-3xl bg-neutral-50/70 border border-neutral-200/80 flex flex-col justify-between relative group hover:border-[#16A36A]/40 transition-colors"
          >
            <div>
              <div className="flex items-center justify-between mb-4">
                <Quote className="w-6 h-6 text-[#16A36A] opacity-40" />
                <span className="text-[10px] font-bold uppercase tracking-wider text-[#68736C] bg-white border border-neutral-200 px-2 py-0.5 rounded">
                  Sample Demonstration
                </span>
              </div>

              <p className="text-xs sm:text-sm text-[#101713] leading-relaxed italic mb-6">
                “{t.comment}”
              </p>
            </div>

            <div className="pt-4 border-t border-neutral-200/60 flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-[#101713]">{t.name}</div>
                <div className="text-[11px] text-[#68736C]">
                  {t.role} · {t.company}
                </div>
              </div>
              <span className="text-xs text-[#075B3B] font-semibold bg-[#EAF8F0] px-2 py-0.5 rounded">
                {t.location}
              </span>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-8 text-center text-xs text-[#68736C] flex items-center justify-center gap-1.5">
        <ShieldCheck className="w-4 h-4 text-[#16A36A]" />
        <span>Growify Digital transparently displays genuine client partnerships and avoids fake invented reviews.</span>
      </div>
    </div>
  );
};
