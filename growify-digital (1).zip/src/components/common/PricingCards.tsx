import React from 'react';
import { Link } from 'react-router-dom';
import { Check, ArrowRight, ShieldAlert, Sparkles, MessageCircle } from 'lucide-react';
import { useCurrency } from '../../context/CurrencyContext';
import { SERVICES } from '../../data/servicesData';
import { COMPANY_INFO } from '../../data/companyData';

interface PricingCardsProps {
  showTitle?: boolean;
}

export const PricingCards: React.FC<PricingCardsProps> = ({ showTitle = true }) => {
  const { currency, setCurrency, formatStartingPrice } = useCurrency();

  return (
    <div className="w-full">
      {showTitle && (
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="text-xs font-bold uppercase tracking-wider text-[#16A36A] mb-2">
            Transparent Investment Architecture
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-[#101713]">
            International Growth Pricing
          </h2>
          <p className="mt-3 text-base text-[#68736C]">
            Tailored growth engagements for ambitious brands. Select your preferred currency below to view starting estimates.
          </p>

          {/* Currency / Region Selector Tabs */}
          <div className="mt-8 inline-flex items-center p-1 bg-neutral-100 rounded-xl border border-neutral-200">
            <button
              type="button"
              onClick={() => setCurrency('INR')}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-lg text-xs font-bold transition-all ${
                currency === 'INR'
                  ? 'bg-white text-[#075B3B] shadow-sm'
                  : 'text-[#68736C] hover:text-[#101713]'
              }`}
            >
              <span className="text-base leading-none">🇮🇳</span>
              <span>India Pricing (INR ₹)</span>
            </button>
            <button
              type="button"
              onClick={() => setCurrency('USD')}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-lg text-xs font-bold transition-all ${
                currency === 'USD'
                  ? 'bg-white text-[#075B3B] shadow-sm'
                  : 'text-[#68736C] hover:text-[#101713]'
              }`}
            >
              <span className="text-base leading-none">🌐</span>
              <span>International Pricing (USD $)</span>
            </button>
          </div>
        </div>
      )}

      {/* Grid of 6 Service Pricing Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {SERVICES.map((s) => {
          const formattedPrice = formatStartingPrice(
            s.startingPriceINR,
            s.startingPriceUSD,
            s.billingPeriod
          );

          return (
            <div
              key={s.id}
              className="flex flex-col justify-between rounded-3xl p-8 bg-white border border-neutral-200/90 hover:border-[#16A36A]/50 hover:shadow-xl transition-all duration-300 relative group"
            >
              <div>
                {/* Header */}
                <div className="flex items-center justify-between gap-2 mb-3">
                  <h3 className="text-xl font-bold text-[#101713] group-hover:text-[#16A36A] transition-colors">
                    {s.title}
                  </h3>
                  <span className="text-[11px] font-semibold uppercase tracking-wider text-[#16A36A] bg-[#EAF8F0] px-2.5 py-1 rounded-md">
                    {s.billingPeriod === 'month' ? 'Monthly' : 'One-Time'}
                  </span>
                </div>

                <p className="text-xs text-[#68736C] line-clamp-2 mb-6 min-h-[32px]">
                  {s.shortDesc}
                </p>

                {/* Price Display */}
                <div className="p-4 rounded-2xl bg-neutral-50 border border-neutral-100 mb-6">
                  <div className="text-[11px] font-semibold text-[#68736C] uppercase tracking-wider">
                    Starting From
                  </div>
                  <div className="mt-1 flex items-baseline gap-1 text-2xl sm:text-3xl font-bold text-[#101713] tracking-tight">
                    <span>{currency === 'INR' ? '₹' : '$'}</span>
                    <span>
                      {currency === 'INR'
                        ? s.startingPriceINR.toLocaleString('en-IN')
                        : s.startingPriceUSD.toLocaleString('en-US')}
                    </span>
                    {s.billingPeriod === 'month' && (
                      <span className="text-xs font-normal text-[#68736C]">/month</span>
                    )}
                  </div>
                  <div className="text-[11px] text-[#68736C] mt-1 italic">
                    *Baseline estimate. Final quote based on project scope.
                  </div>
                </div>

                {/* Key Deliverables Bullet Points */}
                <div className="space-y-2.5 mb-8">
                  <div className="text-xs font-bold text-[#101713] uppercase tracking-wider">
                    Core Inclusions:
                  </div>
                  {s.deliverables.slice(0, 4).map((d, idx) => (
                    <div key={idx} className="flex items-start gap-2.5 text-xs text-[#68736C]">
                      <Check className="w-4 h-4 text-[#16A36A] shrink-0 mt-0.5" />
                      <span className="line-clamp-2">{d}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="space-y-2.5 pt-4 border-t border-neutral-100">
                <Link
                  to={`/contact?service=${s.slug}`}
                  className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl text-xs font-semibold text-white bg-[#16A36A] hover:bg-[#075B3B] transition-colors shadow-2xs group-hover:shadow-sm"
                >
                  <span>Get Custom Quote</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </Link>

                <div className="flex items-center justify-between text-xs px-1">
                  <Link
                    to={`/services/${s.slug}`}
                    className="text-[#68736C] hover:text-[#101713] hover:underline"
                  >
                    View Details &rarr;
                  </Link>

                  <a
                    href={`https://wa.me/${COMPANY_INFO.whatsappRaw}?text=Hello%20Vivek!%20I%E2%80%99d%20like%20a%20custom%20quotation%20for%20Growify%20Digital's%20${encodeURIComponent(
                      s.title
                    )}%20service.`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-[#16A36A] hover:text-[#075B3B] font-semibold"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>WhatsApp</span>
                  </a>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Mandatory Regulatory / Pricing Disclaimers Box */}
      <div className="mt-12 p-6 rounded-2xl bg-neutral-50 border border-neutral-200/80 text-xs text-[#68736C] space-y-3">
        <div className="flex items-center gap-2 text-sm font-bold text-[#101713]">
          <ShieldAlert className="w-4 h-4 text-[#16A36A]" />
          <span>Pricing Terms, Advertising Spend & Consultation Rules</span>
        </div>
        <p className="leading-relaxed">
          <strong>Starting From Notice:</strong> {COMPANY_INFO.pricingDisclaimer}
        </p>
        <p className="leading-relaxed">
          <strong>Platform Ad Spend Policy:</strong> For Google Ads and Meta Ads management, media ad spend is paid directly to Google or Meta and is completely separate from Growify Digital’s professional management retainers.
        </p>
        <p className="leading-relaxed">
          <strong>Performance Integrity:</strong> Growify Digital utilizes data-driven, white-hat marketing practices and optimization frameworks. In accordance with honest international business standards, we do not promise arbitrary guaranteed marketing outcomes or guaranteed #1 Google search rankings.
        </p>
      </div>
    </div>
  );
};
