import React, { useState } from 'react';
import { PORTFOLIO_ITEMS } from '../../data/portfolioData';
import { ArrowUpRight, Sparkles, ExternalLink, X, Eye } from 'lucide-react';
import { PortfolioItem } from '../../types';

export const PortfolioShowcase: React.FC = () => {
  const [activeItem, setActiveItem] = useState<PortfolioItem | null>(null);

  return (
    <div className="w-full">
      {/* Portfolio Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {PORTFOLIO_ITEMS.map((item) => (
          <div
            key={item.id}
            className="group rounded-3xl overflow-hidden bg-white border border-neutral-200/90 hover:border-[#16A36A]/50 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between"
          >
            <div>
              {/* Image Container */}
              <div className="relative aspect-16/10 overflow-hidden bg-neutral-100 cursor-pointer" onClick={() => setActiveItem(item)}>
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  loading="lazy"
                />
                
                {/* Demo Label Overlay */}
                <div className="absolute top-3 left-3 bg-[#101713]/80 backdrop-blur-xs text-white text-[10px] font-semibold uppercase tracking-wider px-2.5 py-1 rounded-md">
                  Demonstration Project
                </div>

                {/* Hover Quick View Button */}
                <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white text-[#101713] text-xs font-semibold shadow-md">
                    <Eye className="w-3.5 h-3.5" />
                    <span>View Demonstration</span>
                  </span>
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <div className="text-[11px] font-semibold text-[#16A36A] uppercase tracking-wider mb-1">
                  {item.category}
                </div>
                <h3 className="text-lg font-bold text-[#101713] group-hover:text-[#16A36A] transition-colors">
                  {item.title}
                </h3>
                <p className="mt-2 text-xs text-[#68736C] leading-relaxed line-clamp-2">
                  {item.description}
                </p>

                {/* Demonstration Metrics */}
                <div className="mt-4 pt-4 border-t border-neutral-100 grid grid-cols-2 gap-2 text-xs">
                  {item.metrics.map((m, idx) => (
                    <div key={idx} className="bg-neutral-50 p-2 rounded-lg">
                      <div className="text-[10px] text-[#68736C] truncate">{m.label}</div>
                      <div className="font-bold text-[#101713] mt-0.5">{m.value}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Tags & Action */}
            <div className="px-6 pb-6 pt-2 flex items-center justify-between text-xs border-t border-neutral-50">
              <div className="flex flex-wrap gap-1.5">
                {item.tags.slice(0, 2).map((t, idx) => (
                  <span key={idx} className="text-[10px] text-neutral-500 bg-neutral-100 px-2 py-0.5 rounded">
                    {t}
                  </span>
                ))}
              </div>

              <button
                type="button"
                onClick={() => setActiveItem(item)}
                className="inline-flex items-center gap-1 font-semibold text-[#16A36A] hover:text-[#075B3B]"
              >
                <span>Details</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Portfolio Item Detail Modal */}
      {activeItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl border border-neutral-200">
            <div className="relative aspect-16/9 bg-neutral-100">
              <img
                src={activeItem.image}
                alt={activeItem.title}
                className="w-full h-full object-cover"
              />
              <button
                type="button"
                onClick={() => setActiveItem(null)}
                className="absolute top-4 right-4 w-9 h-9 rounded-full bg-black/60 hover:bg-black text-white flex items-center justify-center transition-colors focus:outline-none"
                aria-label="Close Preview"
              >
                <X className="w-5 h-5" />
              </button>
              <div className="absolute bottom-3 left-4 bg-black/70 text-white text-[11px] font-semibold px-2.5 py-1 rounded">
                Demonstration Case Study Model
              </div>
            </div>

            <div className="p-6 sm:p-8 space-y-4">
              <div>
                <span className="text-xs font-bold text-[#16A36A] uppercase tracking-wider">
                  {activeItem.category}
                </span>
                <h3 className="text-2xl font-bold text-[#101713] mt-1">{activeItem.title}</h3>
              </div>

              <p className="text-sm text-[#68736C] leading-relaxed">
                {activeItem.description}
              </p>

              <div className="grid grid-cols-2 gap-4 py-2">
                {activeItem.metrics.map((m, idx) => (
                  <div key={idx} className="p-3 bg-neutral-50 rounded-xl border border-neutral-100">
                    <div className="text-xs text-[#68736C]">{m.label}</div>
                    <div className="text-base font-bold text-[#101713] mt-0.5">{m.value}</div>
                  </div>
                ))}
              </div>

              <div className="flex flex-wrap gap-2 pt-2">
                {activeItem.tags.map((tag, idx) => (
                  <span
                    key={idx}
                    className="text-xs font-medium text-[#075B3B] bg-[#EAF8F0] px-3 py-1 rounded-md"
                  >
                    #{tag}
                  </span>
                ))}
              </div>

              <div className="pt-4 border-t border-neutral-100 flex items-center justify-between">
                <span className="text-xs text-[#68736C] italic">
                  *Labelled demonstration model for Growify Digital showcase.
                </span>
                <button
                  type="button"
                  onClick={() => setActiveItem(null)}
                  className="px-5 py-2 rounded-xl text-xs font-semibold bg-neutral-100 hover:bg-neutral-200 text-[#101713] transition-colors"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
