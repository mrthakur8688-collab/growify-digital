import React, { createContext, useContext, useState, useEffect } from 'react';
import { Currency } from '../types';

interface CurrencyContextType {
  currency: Currency;
  setCurrency: (c: Currency) => void;
  formatStartingPrice: (inrAmount: number, usdAmount: number, billingPeriod?: string) => string;
  currencySymbol: string;
}

const CurrencyContext = createContext<CurrencyContextType | undefined>(undefined);

export const CurrencyProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currency, setCurrencyState] = useState<Currency>(() => {
    const saved = localStorage.getItem('growify_currency');
    return (saved === 'USD' || saved === 'INR') ? saved : 'INR';
  });

  const setCurrency = (c: Currency) => {
    setCurrencyState(c);
    localStorage.setItem('growify_currency', c);
  };

  const currencySymbol = currency === 'INR' ? '₹' : '$';

  const formatStartingPrice = (inrAmount: number, usdAmount: number, billingPeriod?: string): string => {
    const amount = currency === 'INR' ? inrAmount.toLocaleString('en-IN') : usdAmount.toLocaleString('en-US');
    const symbol = currencySymbol;
    const period = billingPeriod && billingPeriod !== 'one-time' ? `/${billingPeriod}` : '';
    return `Starting from ${symbol}${amount}${period}`;
  };

  return (
    <CurrencyContext.Provider value={{ currency, setCurrency, formatStartingPrice, currencySymbol }}>
      {children}
    </CurrencyContext.Provider>
  );
};

export const useCurrency = () => {
  const context = useContext(CurrencyContext);
  if (!context) {
    throw new Error('useCurrency must be used within a CurrencyProvider');
  }
  return context;
};
