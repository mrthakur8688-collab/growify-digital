import { PortfolioItem } from '../types';

export const PORTFOLIO_ITEMS: PortfolioItem[] = [
  {
    id: 'demo-fintech',
    title: 'Aura Financial Insights Platform',
    category: 'Website Development & UI/UX',
    description:
      'Conceptual demonstration of a high-speed SaaS analytics portal featuring real-time financial tracking, interactive charts, and sub-second rendering.',
    image: '/src/assets/images/demo_fintech_portal_1793526448188.jpg',
    tags: ['React', 'TypeScript', 'Tailwind CSS', 'High-Speed Web App'],
    metrics: [
      { label: 'Demonstration Benchmark', value: '<0.4s Load' },
      { label: 'Core Web Vitals', value: '100% Score' },
    ],
    isDemoPlaceholder: true,
  },
  {
    id: 'demo-ecommerce',
    title: 'Aeterna Botanicals Luxury Store',
    category: 'UI/UX Design & Conversion Funnel',
    description:
      'Demonstration showcase of a luxury direct-to-consumer e-commerce interface designed with minimalist typography, streamlined checkout, and high conversion flow.',
    image: '/src/assets/images/demo_ecommerce_store_1793526448236.jpg',
    tags: ['E-Commerce UX', 'Design System', 'Figma Prototype'],
    metrics: [
      { label: 'Design Framework', value: 'Figma Auto-Layout' },
      { label: 'Checkout Journey', value: '2-Step Fast Flow' },
    ],
    isDemoPlaceholder: true,
  },
  {
    id: 'demo-healthcare',
    title: 'WellnessHub Patient Management Portal',
    category: 'Full-Stack Web Development',
    description:
      'Demonstration model for medical practices featuring online appointment scheduling, localized patient discovery, and accessible mobile layouts.',
    image: '/src/assets/images/demo_healthcare_app_1793526447986.jpg',
    tags: ['Local Discovery', 'Responsive Web', 'HIPAA-Ready Architecture'],
    metrics: [
      { label: 'Mobile Usability', value: 'AAA Accessible' },
      { label: 'Technical SEO', value: 'Schema Embedded' },
    ],
    isDemoPlaceholder: true,
  },
];
