export const COMPANY_INFO = {
  name: 'Growify Digital',
  tagline: 'We Build Digital Experiences That Grow Businesses.',
  subtagline:
    'From powerful websites to data-driven digital marketing, we help ambitious businesses build, grow and succeed online.',
  industry: 'Digital Marketing, Website Development and Creative Technology',
  logoUrl: '/public/assets/aistudio/growigylogo_884d1fae.jpeg',
  
  // Founder details
  founder: {
    name: 'Vivek Singh',
    title: 'Founder, Growify Digital',
    photoUrl: '/public/assets/aistudio/WhatsApp_Image_2026-07-25_at_2.10.13_PM_91f832b0.jpeg',
    introduction:
      'At Growify Digital, our vision is to help businesses build a stronger digital presence through creative thinking, meaningful design and smart digital strategies. We believe every business deserves an opportunity to grow in the digital world.',
    personalVision:
      'To build an internationally recognized growth studio where creativity, engineering precision, and performance marketing converge to unlock sustainable digital scale for forward-thinking enterprises.',
    mission:
      'We empower ambitious companies across India, the US, the UK, Canada, and Australia with high-converting web experiences, organic search visibility, and calculated ad strategies that drive predictable revenue.',
    philosophy:
      'True growth is never accidental. It is the calculated compound of strategic clarity, pixel-perfect craft, transparent iteration, and relentless commercial discipline.',
    messageToClients:
      'When you partner with Growify Digital, you gain an agile growth partner dedicated to your bottom line. We treat your brand with the same rigor, respect, and relentless pursuit of excellence that we demand of ourselves.',
    linkedin: 'https://www.linkedin.com/in/vivek-singh-324056426',
  },

  // Contact details
  email: 'hello.growify@gmail.com',
  whatsappNumber: '+91 9302584559',
  whatsappRaw: '919302584559',
  whatsappPrefilledText:
    'Hello Growify Digital! I’m interested in your digital marketing services. I’d like to discuss my business requirements and get a customized proposal.',
  whatsappUrl:
    'https://wa.me/919302584559?text=Hello%20Growify%20Digital!%20I%E2%80%99m%20interested%20in%20your%20digital%20marketing%20services.%20I%E2%80%99d%20like%20to%20discuss%20my%20business%20requirements%20and%20get%20a%20customized%20proposal.',

  // Social Links
  socials: {
    instagram: 'https://www.instagram.com/growifydigital_?dlrf=cXFvOTliZnNhdDBy',
    facebook: 'https://www.facebook.com/share/1BWV3c4HMa/?mibextid=wwXIfr',
    linkedin: 'https://www.linkedin.com/in/vivek-singh-324056426',
  },

  // Target Markets
  targetMarkets: [
    { country: 'India', flag: '🇮🇳', currency: 'INR' },
    { country: 'United States', flag: '🇺🇸', currency: 'USD' },
    { country: 'United Kingdom', flag: '🇬🇧', currency: 'USD' },
    { country: 'Canada', flag: '🇨🇦', currency: 'USD' },
    { country: 'Australia', flag: '🇦🇺', currency: 'USD' },
  ],

  // Core Values
  values: [
    {
      title: 'Strategy First',
      description:
        'We never write a line of code or launch an ad campaign without a thorough audit of your market dynamics, audience intent, and commercial objectives.',
    },
    {
      title: 'Creative Execution',
      description:
        'Design is not merely visual ornament; it is your highest-leverage conversion mechanism. We build interfaces and creatives that captivate and convert.',
    },
    {
      title: 'Transparent Communication',
      description:
        'Clear milestones, real-time dashboards, and honest recommendations. No vanity metrics or opaque agency jargon.',
    },
    {
      title: 'Continuous Improvement',
      description:
        'Launch is only day one. We consistently monitor analytics, conduct A/B tests, and refine user flows to maximize your return on investment.',
    },
  ],

  // 5-Step Process
  process: [
    {
      step: '01',
      name: 'Discover',
      tagline: 'Deep Audit & Competitive Mapping',
      description:
        'We analyze your current digital footprints, user friction points, market landscape, and commercial targets to identify untapped growth leverage.',
    },
    {
      step: '02',
      name: 'Strategize',
      tagline: 'Growth Architecture & Technical Blueprint',
      description:
        'We establish target personas, conversion funnels, keyword taxonomies, technical stack parameters, and measurable KPIs for your campaign.',
    },
    {
      step: '03',
      name: 'Create',
      tagline: 'Precision Craft & Agile Development',
      description:
        'Our engineers and designers construct fast, responsive web assets, high-converting design systems, and targeted advertising ad creatives.',
    },
    {
      step: '04',
      name: 'Launch',
      tagline: 'Deployment & Quality Verification',
      description:
        'Rigorous cross-device testing, technical SEO verification, analytics tracking implementation, and coordinated multi-channel go-live.',
    },
    {
      step: '05',
      name: 'Optimize',
      tagline: 'Data-Driven Iteration & Scaling',
      description:
        'Continuous performance monitoring, conversion rate optimization, search ranking expansion, and ad budget scaling to maximize ROI.',
    },
  ],

  // Pricing Disclaimer
  pricingDisclaimer:
    'Final pricing depends on business requirements, project scope, features, complexity and deliverables. Contact us for a customized proposal. Advertising spend is paid directly to advertising platforms and is separate from agency management fees.',
};
