export interface SampleTestimonial {
  id: string;
  name: string;
  role: string;
  company: string;
  location: string;
  comment: string;
  serviceCategory: string;
  isSamplePlaceholder: boolean;
}

export const SAMPLE_TESTIMONIALS: SampleTestimonial[] = [
  {
    id: 'sample-1',
    name: 'Sample Client Profile',
    role: 'Managing Director',
    company: 'Enterprise Software Studio',
    location: 'United States',
    comment:
      'This is a demonstration review format illustrating how client case feedback will be showcased. Growify Digital focuses on technical rigor, rapid communication, and conversion-engineered deliverables.',
    serviceCategory: 'Website Development',
    isSamplePlaceholder: true,
  },
  {
    id: 'sample-2',
    name: 'Sample Founder Profile',
    role: 'Founder & CEO',
    company: 'Boutique Retail Brand',
    location: 'United Kingdom',
    comment:
      'Demonstration feedback slot for upcoming verified client reviews. Transparent reporting, disciplined ad campaigns, and clean UI/UX designs form the core of Growify’s engagement model.',
    serviceCategory: 'Meta & Google Ads',
    isSamplePlaceholder: true,
  },
  {
    id: 'sample-3',
    name: 'Sample Operations Lead',
    role: 'Operations Director',
    company: 'Commercial Healthcare Practice',
    location: 'India',
    comment:
      'Placeholder demonstration of future client endorsements. Dedicated attention from Vivek Singh and the team ensures tailored solutions rather than one-size-fits-all agency packages.',
    serviceCategory: 'SEO & Local SEO',
    isSamplePlaceholder: true,
  },
];
