import { ServiceDetail } from '../types';

export const SERVICES: ServiceDetail[] = [
  {
    id: 'web-development',
    slug: 'web-development',
    title: 'Website Development',
    tagline: 'High-Performance, Conversion-Engineered Web Experiences',
    shortDesc:
      'Lightning-fast, mobile-responsive web applications and corporate websites engineered for conversion, speed, and search dominance.',
    fullDesc:
      'We design and build bespoke web experiences that elevate your brand and drive measurable revenue. Using cutting-edge modern technologies like React, Next.js, TypeScript, and modern headless architectures, every website we deliver is optimized for sub-second load times, technical SEO compliance, and fluid responsiveness across desktop, tablet, and mobile devices.',
    startingPriceINR: 15000,
    startingPriceUSD: 299,
    billingPeriod: 'one-time',
    icon: 'Globe',
    accentGradient: 'from-emerald-500 to-teal-700',
    problemsSolved: [
      {
        title: 'Slow Loading & High Bounce Rates',
        description:
          'Bloated templates and unoptimized assets drive away over 50% of mobile visitors before your page even renders.',
      },
      {
        title: 'Poor Mobile Experience',
        description:
          'Clunky, non-responsive mobile designs that frustrate buyers and cripple your search engine rankings.',
      },
      {
        title: 'Low Visitor-to-Lead Conversion',
        description:
          'Websites that look like brochures instead of strategic sales funnels with clear calls-to-action and trust anchors.',
      },
      {
        title: 'Broken Technical SEO Foundations',
        description:
          'Missing schema markup, improper canonicals, and indexation hurdles that keep your site invisible on search engines.',
      },
    ],
    processSteps: [
      {
        step: '01',
        title: 'Architecture & User Flow Planning',
        description: 'Mapping sitemaps, information architecture, wireframes, and conversion funnels.',
      },
      {
        step: '02',
        title: 'UI/UX Design Alignment',
        description: 'Crafting responsive desktop and mobile prototypes in line with your visual brand identity.',
      },
      {
        step: '03',
        title: 'Full-Stack Development',
        description: 'Writing clean, semantic, type-safe code with modular component architecture and responsive styling.',
      },
      {
        step: '04',
        title: 'Speed, SEO & Accessibility Audit',
        description: 'Benchmarking Core Web Vitals, testing cross-browser compatibility, and validating structured data.',
      },
      {
        step: '05',
        title: 'Deployment & Training',
        description: 'Launching on high-speed global CDNs (Cloudflare / Vercel), configuring domains, and handover.',
      },
    ],
    keyBenefits: [
      {
        title: 'Sub-Second Page Load Speeds',
        description: 'Optimized assets and clean code guarantee top Core Web Vitals and lower bounce rates.',
        metric: '95+ Lighthouse Score',
      },
      {
        title: 'Mobile-First Responsive Layouts',
        description: 'Flawless presentation and touch-friendly navigation across iPhone, Android, tablets, and 4K displays.',
        metric: '100% Cross-Device',
      },
      {
        title: 'Built-in Technical SEO Architecture',
        description: 'Pre-configured OpenGraph metadata, Schema.org JSON-LD, sitemaps, and search-engine-friendly URLs.',
        metric: 'Search Ready',
      },
      {
        title: 'Conversion-Focused Funnels',
        description: 'Frictionless lead forms, strategic trust badges, and prominent WhatsApp chat integration.',
        metric: 'High Conversion',
      },
    ],
    deliverables: [
      'Complete custom-coded responsive website or web app',
      'Mobile-first responsive layout (iOS, Android, Tablet, Desktop)',
      'High-speed deployment & SSL configuration',
      'Technical SEO foundation (Meta tags, OpenGraph, Sitemap, Robots.txt)',
      'Schema.org structured data implementation',
      'Interactive contact forms with spam protection & WhatsApp integration',
      'Google Analytics 4 & Google Search Console integration setup',
      'Post-launch testing & 30-day technical warranty',
    ],
    faqs: [
      {
        question: 'How long does it take to build a website?',
        answer:
          'Project timelines typically range from 1 to 3 weeks depending on the number of pages, custom features, and content readiness. We provide a clear milestone calendar before commencing development.',
      },
      {
        question: 'Will my website work smoothly on all mobile phones?',
        answer:
          'Yes, absolutely. We design with a mobile-first philosophy, ensuring fast touch navigation, legible typography, and fluid responsiveness across every screen size.',
      },
      {
        question: 'Can you migrate my existing website to a faster platform?',
        answer:
          'Yes. We regularly migrate legacy WordPress or slow DIY builder websites to high-speed React/Next.js architectures while preserving existing URL structures and SEO equity.',
      },
      {
        question: 'Is domain and hosting included in the pricing?',
        answer:
          'Domain registration and 3rd-party hosting subscriptions are typically owned directly by the client for full ownership security, but we guide you through setup and deploy your code to top-tier global hosting.',
      },
    ],
    metaTitle: 'Website Development Services — Growify Digital | Fast, Modern Web Development',
    metaDesc:
      'Growify Digital crafts high-performance, mobile-responsive, conversion-focused websites for businesses across India, USA, UK, Canada, and Australia.',
    targetKeywords: ['Website Development Company', 'Website Development Services', 'Custom Web Development', 'Web Development Agency India', 'Responsive Web Design'],
  },
  {
    id: 'ui-ux-design',
    slug: 'ui-ux-design',
    title: 'UI/UX Design',
    tagline: 'Human-Centered Digital Interfaces That Inspire & Convert',
    shortDesc:
      'World-class visual systems, interactive wireframes, and intuitive user experiences crafted with minimalist luxury and conversion psychology.',
    fullDesc:
      'Great design is the competitive moat of modern digital business. At Growify Digital, our UI/UX design services blend aesthetic luxury with behavioral science. We build clear user journeys, eliminate checkout friction, and deliver high-fidelity design systems in Figma that transform casual visitors into passionate brand advocates.',
    startingPriceINR: 8000,
    startingPriceUSD: 149,
    billingPeriod: 'one-time',
    icon: 'Palette',
    accentGradient: 'from-emerald-600 to-teal-800',
    problemsSolved: [
      {
        title: 'Confusing Navigation & Drop-Off',
        description: 'Visitors unable to find key products or pricing within 5 seconds, resulting in immediate churn.',
      },
      {
        title: 'Dated Visual Brand Image',
        description: 'Unprofessional aesthetic that diminishes user trust and undermines premium pricing power.',
      },
      {
        title: 'Cluttered Checkout & Inquiry Flows',
        description: 'Complex multi-step forms that create buyer hesitation and abandoned transactions.',
      },
      {
        title: 'Inconsistent Cross-Platform Experience',
        description: 'Disjointed typography, colors, and button styles between marketing pages and web applications.',
      },
    ],
    processSteps: [
      {
        step: '01',
        title: 'User Research & Competitor Benchmarking',
        description: 'Analyzing target audience behaviors, pain points, and best-in-class industry precedents.',
      },
      {
        step: '02',
        title: 'Information Architecture & Wireframing',
        description: 'Structuring low-fidelity layouts and user flows focused strictly on conversion paths.',
      },
      {
        step: '03',
        title: 'Design System & Visual Language',
        description: 'Defining typography hierarchy, color scales, components, micro-interactions, and icon sets.',
      },
      {
        step: '04',
        title: 'High-Fidelity Interactive Prototyping',
        description: 'Delivering clickable interactive prototypes in Figma with realistic states and transitions.',
      },
      {
        step: '05',
        title: 'Developer Handoff & Design Audit',
        description: 'Supplying comprehensive component specs, tokens, and asset exports ready for development.',
      },
    ],
    keyBenefits: [
      {
        title: 'Minimalist Luxury Aesthetic',
        description: 'Clean whitespace, elegant typography, and refined palettes that inspire immediate brand authority.',
        metric: 'Premium Feel',
      },
      {
        title: 'Reduced User Cognitive Load',
        description: 'Streamlined visual hierarchy that guides prospective clients naturally toward conversion actions.',
        metric: 'Intuitive Flow',
      },
      {
        title: 'Modular Design Tokens',
        description: 'Reusable UI libraries that accelerate future development by up to 40%.',
        metric: 'Design Systems',
      },
      {
        title: 'Zero-Guesswork Handoff',
        description: 'Pixel-perfect specifications, responsive variants, and auto-layout frames ready for code.',
        metric: 'Clean Handoff',
      },
    ],
    deliverables: [
      'Comprehensive Figma workspace files with full edit access',
      'Mobile and desktop responsive screen layouts',
      'Design system library (Typography, Colors, Spacing, Buttons, Inputs)',
      'Clickable user journey prototypes',
      'Custom vector iconography and asset exports (SVG, PNG)',
      'Design handoff documentation for developers',
      'Interactive micro-interaction guidelines',
    ],
    faqs: [
      {
        question: 'What tools do you use for UI/UX design?',
        answer:
          'We work predominantly in Figma, the global industry standard for collaborative product and web design. You receive full ownership of all source files and assets.',
      },
      {
        question: 'Do you create both desktop and mobile versions?',
        answer:
          'Yes. Every screen is designed with dedicated desktop, tablet, and mobile viewport adaptations to ensure seamless usability across all devices.',
      },
      {
        question: 'Can you redesign our existing app or website without changing backend logic?',
        answer:
          'Yes! We frequently conduct UX audits and redesign user flows while preserving your existing backend architecture or database models.',
      },
      {
        question: 'Do you provide code alongside design files?',
        answer:
          'Our UI/UX design service delivers comprehensive Figma files and assets. If you also require frontend implementation, you can combine this with our Website Development service for a turnkey solution.',
      },
    ],
    metaTitle: 'UI/UX Design Agency — Growify Digital | Premium Product & Web Interfaces',
    metaDesc:
      'Transform your digital presence with human-centered UI/UX design. Growify Digital creates intuitive, elegant web and mobile interfaces that maximize conversions.',
    targetKeywords: ['UI UX Design Agency', 'UI Design Services', 'UX Research', 'Figma Website Design', 'User Interface Design India'],
  },
  {
    id: 'seo',
    slug: 'seo',
    title: 'Search Engine Optimization (SEO)',
    tagline: 'Sustainable Organic Search Dominance & Intent-Driven Traffic',
    shortDesc:
      'Comprehensive technical SEO, keyword architecture, on-page optimization, and authoritative backlink strategies for long-term growth.',
    fullDesc:
      'Paid advertising stops the moment your budget runs dry, but organic search visibility compounds month after month. Growify Digital builds search engine optimization strategies rooted in high-intent keyword discovery, bulletproof technical crawlability, and authoritative content clusters. We help you outrank competitors and capture customers at the exact moment they search for your solutions.',
    startingPriceINR: 7000,
    startingPriceUSD: 149,
    billingPeriod: 'month',
    icon: 'Search',
    accentGradient: 'from-emerald-500 to-teal-700',
    problemsSolved: [
      {
        title: 'Total Invisibility on Google',
        description: 'Your ideal buyers are searching for your core services every day, but your competitors capture 100% of the clicks.',
      },
      {
        title: 'Crawl & Indexation Roadblocks',
        description: 'Duplicate meta descriptions, broken internal links, and slow speeds preventing Googlebot from indexing your pages.',
      },
      {
        title: 'Wasted Effort on Low-Intent Traffic',
        description: 'Ranking for obscure keywords that bring page views but zero phone calls, inquiries, or sales.',
      },
      {
        title: 'Algorithm Update Vulnerability',
        description: 'Black-hat shortcuts and spammy backlinks that put your domain at risk of severe Google penalties.',
      },
    ],
    processSteps: [
      {
        step: '01',
        title: 'Technical & On-Page Health Audit',
        description: 'Inspecting indexability, Core Web Vitals, XML sitemaps, status codes, and structural tag hierarchies.',
      },
      {
        step: '02',
        title: 'Commercial Intent Keyword Research',
        description: 'Identifying high-intent, low-to-medium difficulty search queries that directly align with buyer readiness.',
      },
      {
        step: '03',
        title: 'On-Page Optimization & Schema Injection',
        description: 'Optimizing titles, meta descriptions, H1-H3 structures, image alt tags, and JSON-LD structured data.',
      },
      {
        step: '04',
        title: 'Content Architecture & Internal Linking',
        description: 'Building thematic topic clusters that establish topical authority in your industry niche.',
      },
      {
        step: '05',
        title: 'Monthly Performance & Ranking Reports',
        description: 'Tracking organic impressions, clicks, keyword positions, and lead conversions via Search Console & GA4.',
      },
    ],
    keyBenefits: [
      {
        title: 'Zero Ad-Spend Traffic Growth',
        description: 'Generate high-intent qualified inbound leads without paying cost-per-click to ad networks.',
        metric: 'Organic Scale',
      },
      {
        title: 'High-Intent Buyer Capture',
        description: 'Target keywords used by decision-makers ready to request a quote or purchase.',
        metric: 'Buyer Intent',
      },
      {
        title: 'Compounding Digital Asset Value',
        description: 'High search rankings continue generating inquiries for months and years into the future.',
        metric: 'Compounding ROI',
      },
      {
        title: '100% White-Hat Practices',
        description: 'Strict adherence to Google Search Essentials and Webmaster Guidelines for bulletproof safety.',
        metric: 'Penalty Free',
      },
    ],
    deliverables: [
      'Comprehensive baseline technical SEO audit report',
      'Full keyword research roadmap with search volumes and difficulty scores',
      'Meta title, description, and header tag optimization across all core pages',
      'Schema.org structured data implementation (Organization, Breadcrumbs, FAQs, Services)',
      'XML sitemap and robots.txt audit & Google Search Console indexing submission',
      'Core Web Vitals and page speed recommendations',
      'Monthly organic growth & search ranking progress report',
    ],
    faqs: [
      {
        question: 'Do you promise guaranteed #1 rankings on Google?',
        answer:
          'No ethical agency guarantees #1 rankings, as Google algorithms update constantly and search is influenced by hundreds of factors. What we guarantee is rigorous, 100% white-hat technical, structural, and content optimization designed to maximize your visibility and organic leads.',
      },
      {
        question: 'How long does SEO take to produce measurable results?',
        answer:
          'Typically, technical improvements and initial ranking movements appear within 60 to 90 days, with significant compounding organic traffic growth visible over 4 to 6 months of sustained execution.',
      },
      {
        question: 'Do I need to sign a long-term lock-in contract?',
        answer:
          'No. Our monthly SEO retainers operate on a flexible month-to-month basis. We retain our clients through measurable performance, clear reporting, and genuine business value.',
      },
      {
        question: 'Will you need access to my website backend?',
        answer:
          'Yes, to implement on-page titles, schema markup, and speed optimizations, we typically require access to your CMS or codebase, along with Google Search Console and Analytics.',
      },
    ],
    metaTitle: 'SEO Services — Growify Digital | Data-Driven Search Engine Optimization',
    metaDesc:
      'Boost your organic rankings, traffic, and revenue with white-hat SEO services from Growify Digital. Technical audits, on-page SEO, and keyword dominance.',
    targetKeywords: ['SEO Services', 'Search Engine Optimization', 'Technical SEO', 'Organic SEO Agency', 'SEO Agency India', 'SEO Services USA'],
  },
  {
    id: 'local-seo',
    slug: 'local-seo',
    title: 'Local SEO & Google Business Profile',
    tagline: 'Dominate Nearby Searches & Capture High-Intent Local Customers',
    shortDesc:
      'Google Business Profile optimization, local citation building, map pack rankings, and neighborhood keyword visibility.',
    fullDesc:
      'When nearby customers search for "near me" services, your business must appear directly in the coveted Google Map 3-Pack. Growify Digital optimizes your Google Business Profile (GBP), standardizes local NAP (Name, Address, Phone) citations, and builds localized authority signals so your phone rings with nearby buyers.',
    startingPriceINR: 5000,
    startingPriceUSD: 99,
    billingPeriod: 'month',
    icon: 'MapPin',
    accentGradient: 'from-emerald-600 to-teal-800',
    problemsSolved: [
      {
        title: 'Hidden From Google Map 3-Pack',
        description: 'Local competitors capturing 70%+ of neighborhood calls because your business doesn’t appear on the top map view.',
      },
      {
        title: 'Inconsistent NAP Citations',
        description: 'Conflicting phone numbers, addresses, and hours across business directories confusing search engines and customers.',
      },
      {
        title: 'Unoptimized Google Business Profile',
        description: 'Missing service categories, zero keyword-rich updates, and unanswered customer reviews.',
      },
      {
        title: 'Zero Local Organic Authority',
        description: 'Website lacks local geo-signals, localized landing pages, and structured LocalBusiness schema.',
      },
    ],
    processSteps: [
      {
        step: '01',
        title: 'Google Business Profile Audit',
        description: 'Verifying primary and secondary categories, service areas, attributes, hours, and media assets.',
      },
      {
        step: '02',
        title: 'Local Citation & NAP Cleanup',
        description: 'Auditing and aligning business name, address, and phone consistency across top authoritative directories.',
      },
      {
        step: '03',
        title: 'Localized On-Page Schema Setup',
        description: 'Embedding LocalBusiness JSON-LD markup, city/state keywords, and Google Map embeds on your website.',
      },
      {
        step: '04',
        title: 'Review Acceleration & GBP Content',
        description: 'Setting up ethical review capture workflows and publishing optimized Google updates and photos.',
      },
      {
        step: '05',
        title: 'Map Rank Tracking & Monthly Reporting',
        description: 'Monitoring local geo-grid rankings, call button clicks, direction requests, and website visits.',
      },
    ],
    keyBenefits: [
      {
        title: 'Google Map 3-Pack Dominance',
        description: 'Capture the highest-converting real estate on local mobile and desktop search results.',
        metric: 'Top Map Real Estate',
      },
      {
        title: 'High-Intent Inbound Phone Calls',
        description: 'Connect immediately with nearby customers searching with urgent purchase intent.',
        metric: 'Direct Calls',
      },
      {
        title: 'Consistent Local Trust Signals',
        description: 'Accurate business data across Google, Apple Maps, Bing, and major business directories.',
        metric: '100% NAP Match',
      },
      {
        title: 'Reputation & Review Growth',
        description: 'Systematic strategies to encourage genuine 5-star customer reviews that boost trust.',
        metric: 'Social Proof',
      },
    ],
    deliverables: [
      'Complete Google Business Profile optimization & category verification',
      'LocalBusiness Schema.org JSON-LD structured data code',
      'Audit of existing local citations and directory listings',
      'Monthly citation expansion on authoritative local portals',
      'Localized geo-targeted keyword strategy',
      'Review generation guidance and response templates',
      'Monthly local search insights (Calls, Direction requests, Website visits)',
    ],
    faqs: [
      {
        question: 'Who needs Local SEO services?',
        answer:
          'Any business with a physical storefront, clinic, showroom, or local service territory (such as dentists, legal firms, contractors, real estate agencies, cafes, and consultants) that serves a specific geographic area.',
      },
      {
        question: 'Can you help if our Google Business Profile was suspended?',
        answer:
          'Yes, we assist with compliance audits and reinstatement appeals in strict adherence to Google Business Profile guidelines.',
      },
      {
        question: 'How quickly can we see an increase in local calls?',
        answer:
          'Profile optimization, category fixes, and citation cleanup often produce noticeable increases in map views, call clicks, and direction requests within 3 to 6 weeks.',
      },
      {
        question: 'What if we operate in multiple cities or service areas?',
        answer:
          'We design localized multi-location landing pages and configure your service-area profile to rank across neighboring target zones.',
      },
    ],
    metaTitle: 'Local SEO Services — Growify Digital | Google Business Profile & Map Pack Ranking',
    metaDesc:
      'Dominate local search results and Google Maps with Growify Digital. Attract high-intent local customers, drive phone calls, and grow your local market share.',
    targetKeywords: ['Local SEO Services', 'Google Business Profile Optimization', 'Google Map 3 Pack', 'Local Search Marketing', 'Local SEO Agency'],
  },
  {
    id: 'google-ads',
    slug: 'google-ads',
    title: 'Google Ads Management',
    tagline: 'High-Intent Search & Performance Max Campaigns That Drive High ROI',
    shortDesc:
      'Laser-focused Google Search, Performance Max, Display, and Remarketing campaigns built to generate profitable leads and purchases.',
    fullDesc:
      'Stop burning marketing budget on irrelevant search clicks. Growify Digital builds disciplined Google Ads campaigns focused on buyer search intent, granular negative keyword lists, high-relevance ad copy, and conversion-tracking accuracy. Every dollar spent is tied directly to qualified leads and measurable return on ad spend (ROAS).',
    startingPriceINR: 5000,
    startingPriceUSD: 99,
    billingPeriod: 'month',
    icon: 'Target',
    accentGradient: 'from-emerald-500 to-teal-700',
    problemsSolved: [
      {
        title: 'Burning Budget on Junk Clicks',
        description: 'Broad match traps and missing negative keywords draining your budget on freebie-seekers and unrelated queries.',
      },
      {
        title: 'Poor Quality Scores & High CPCs',
        description: 'Disconnect between ad copy, keywords, and landing pages inflating cost-per-click while killing ad rank.',
      },
      {
        title: 'Broken Conversion Tracking',
        description: 'Running campaigns blind with unverified Google Tag Manager triggers, misattributed leads, and duplicate pixels.',
      },
      {
        title: 'Unprofitable Ad Spend',
        description: 'Spending thousands without knowing your exact Customer Acquisition Cost (CAC) or Return on Ad Spend (ROAS).',
      },
    ],
    processSteps: [
      {
        step: '01',
        title: 'Account & Conversion Tracking Audit',
        description: 'Configuring Google Tag Manager, GA4 event tags, offline conversions, and call tracking.',
      },
      {
        step: '02',
        title: 'Search Intent & Competitor Research',
        description: 'Uncovering competitor ad copies, target CPC bids, and high-converting commercial search terms.',
      },
      {
        step: '03',
        title: 'Campaign Architecture & Ad Copywriting',
        description: 'Structuring tight Single-Theme Ad Groups (STAGs), Responsive Search Ads, and high-impact ad extensions.',
      },
      {
        step: '04',
        title: 'Negative Keyword & Bid Optimization',
        description: 'Aggressively pruning wasteful search terms and fine-tuning Smart Bidding strategies (Target CPA / ROAS).',
      },
      {
        step: '05',
        title: 'Landing Page & Conversion Rate Optimization',
        description: 'Aligning headline messaging and eliminating form friction to maximize visitor-to-customer conversion.',
      },
    ],
    keyBenefits: [
      {
        title: 'Immediate Inbound Leads',
        description: 'Place your offer directly at the top of Google for prospects ready to buy right now.',
        metric: 'Instant Visibility',
      },
      {
        title: 'Aggressive Budget Discipline',
        description: 'Exhaustive negative keyword lists prevent wasteful clicks on irrelevant searches.',
        metric: 'Zero Waste',
      },
      {
        title: 'Higher Quality Scores',
        description: 'Tight keyword-to-copy-to-page alignment lowers your average Cost Per Click (CPC).',
        metric: 'Lower CPCs',
      },
      {
        title: 'Transparent Reporting Dashboard',
        description: 'Real-time visibility into ad spend, cost per lead, click-through rate, and closed revenue.',
        metric: 'Clear Attribution',
      },
    ],
    deliverables: [
      'Complete Google Ads account setup or restructuring',
      'Keyword research & competitor bid analysis',
      'Responsive Search Ads (RSA) with custom headlines, descriptions & assets',
      'Granular negative keyword lists to prevent wasted spend',
      'Google Tag Manager conversion tracking implementation',
      'Call tracking & lead attribution setup',
      'Weekly bid adjustments & negative keyword pruning',
      'Monthly ROI, CPA & performance analysis report',
    ],
    faqs: [
      {
        question: 'Is the ad spend included in the management fee?',
        answer:
          'No. Ad spend is billed directly by Google to your own payment method. Our monthly fee covers professional strategy, setup, copywriting, testing, bid management, and continuous optimization.',
      },
      {
        question: 'What is the recommended minimum monthly ad spend?',
        answer:
          'While you can start with any budget, we generally recommend a minimum monthly media spend of ₹15,000 in India or $500 for international markets to gather sufficient click data for algorithmic machine learning.',
      },
      {
        question: 'Do I own my Google Ads account?',
        answer:
          'Yes, 100%. You retain full ownership and billing control of your Google Ads account. We connect as an authorized manager.',
      },
      {
        question: 'How quickly can campaigns go live?',
        answer:
          'Once tracking, ad copy, and landing page assets are approved, campaigns can typically be launched within 3 to 5 business days.',
      },
    ],
    metaTitle: 'Google Ads Management — Growify Digital | High-ROI PPC & Performance Max Campaigns',
    metaDesc:
      'Maximize your return on ad spend with Google Ads management from Growify Digital. Laser-targeted search ads, negative keyword discipline, and transparent lead tracking.',
    targetKeywords: ['Google Ads Management', 'PPC Agency', 'Google Ads Agency India', 'Google Ads Management USA', 'Search Engine Marketing', 'PPC Management Services'],
  },
  {
    id: 'meta-ads',
    slug: 'meta-ads',
    title: 'Meta Ads Management (Facebook & Instagram)',
    tagline: 'High-Converting Social Creative, Lookalikes & Full-Funnel Scaling',
    shortDesc:
      'Scroll-stopping visual creatives, audience targeting, Meta Pixel / Conversions API tracking, and retargeting funnels.',
    fullDesc:
      'With billions of active users on Instagram and Facebook, Meta Ads offer unmatched audience scale. But running generic boost posts wastes budget. Growify Digital engineers full-funnel Meta advertising systems combining captivating visual hooks, audience segmentation, Meta Conversions API (CAPI) server tracking, and dynamic retargeting to generate predictable sales and customer inquiries.',
    startingPriceINR: 5000,
    startingPriceUSD: 99,
    billingPeriod: 'month',
    icon: 'Megaphone',
    accentGradient: 'from-emerald-600 to-teal-800',
    problemsSolved: [
      {
        title: 'Burning Money on "Boost Post" Buttons',
        description: 'Using superficial boost buttons that accumulate empty likes instead of qualified leads and real sales.',
      },
      {
        title: 'Ad Fatigue & Creative Burnout',
        description: 'Running the same tired creatives for months until cost-per-acquisition skyrockets and frequency stalls.',
      },
      {
        title: 'iOS Privacy / Signal Loss',
        description: 'Losing attribution and audience targeting data without a proper server-side Meta Conversions API (CAPI) setup.',
      },
      {
        title: 'No Structured Retargeting Funnel',
        description: 'Ignoring the 97% of visitors who leave without purchasing on their first visit.',
      },
    ],
    processSteps: [
      {
        step: '01',
        title: 'Audience & Offer Architecture',
        description: 'Defining core customer avatars, lead magnets, irresistible offers, and hook angles.',
      },
      {
        step: '02',
        title: 'Pixel & Conversions API (CAPI) Setup',
        description: 'Configuring Meta Pixel, server-side CAPI events, and domain verification for maximum signal fidelity.',
      },
      {
        step: '03',
        title: 'High-Impact Creative Production',
        description: 'Designing high-converting ad visuals, compelling video hooks, and persuasive direct-response ad copy.',
      },
      {
        step: '04',
        title: 'Full-Funnel Campaign Launch',
        description: 'Deploying Top-of-Funnel (prospecting), Middle-of-Funnel (consideration), and Bottom-of-Funnel (retargeting) ad sets.',
      },
      {
        step: '05',
        title: 'Creative Testing & Budget Scaling',
        description: 'Systematically testing headlines, hooks, and formats while scaling winning ad sets to maximize return.',
      },
    ],
    keyBenefits: [
      {
        title: 'Scroll-Stopping Ad Creatives',
        description: 'Direct-response visual designs and hooks crafted to stop thumbs and drive clicks.',
        metric: 'High Click-Through',
      },
      {
        title: 'Server-Side CAPI Tracking',
        description: 'Bypass browser ad-blockers and iOS privacy constraints with resilient server-side event tracking.',
        metric: 'Reliable Signal',
      },
      {
        title: 'Full-Funnel Retargeting',
        description: 'Re-engage cart abandoners, video viewers, and previous website visitors with customized offers.',
        metric: 'Higher ROAS',
      },
      {
        title: 'Direct WhatsApp Ad Integration',
        description: 'Route interested prospects straight into interactive WhatsApp conversations for instant closing.',
        metric: 'Instant Chat Leads',
      },
    ],
    deliverables: [
      'Full Meta Business Manager & Ad Account setup or audit',
      'Meta Pixel and Conversions API (CAPI) tracking configuration',
      'Target audience research (Custom audiences, Lookalikes & Interest clusters)',
      'Direct-response ad creative concepts (Static graphics, carousels & copy variations)',
      'Lead form campaigns and landing page conversion funnels',
      'Full-funnel retargeting structure',
      'Weekly A/B creative testing & frequency management',
      'Monthly performance dashboard with CPA, ROAS and lead metrics',
    ],
    faqs: [
      {
        question: 'Can you run "Click-to-WhatsApp" ads for our business?',
        answer:
          'Yes! Click-to-WhatsApp ads are one of our highest-converting specialties, particularly for service businesses and high-touch sales where immediate WhatsApp conversations drive faster deal closures.',
      },
      {
        question: 'Do you create the graphics and copy for the ads?',
        answer:
          'Yes. We handle end-to-end ad creative production, including direct-response copywriting, headline hooks, and graphic design tailored to Instagram and Facebook feed and story formats.',
      },
      {
        question: 'How do you prevent ad fatigue?',
        answer:
          'We maintain a continuous creative pipeline, regularly rotating new visual hooks, headline angles, and formats to ensure your frequency stays healthy and acquisition costs remain low.',
      },
      {
        question: 'Is ad spend included in the agency fee?',
        answer:
          'No. Media spend is paid directly to Meta (Facebook/Instagram) via your ad account payment method. Our management fee covers campaign strategy, design, tracking, copywriting, and daily optimization.',
      },
    ],
    metaTitle: 'Meta Ads Agency — Growify Digital | Facebook & Instagram Ads Management',
    metaDesc:
      'Scale your business with high-converting Facebook & Instagram ads from Growify Digital. Scroll-stopping creatives, CAPI tracking, and profitable social funnels.',
    targetKeywords: ['Meta Ads Agency', 'Facebook Ads Management', 'Instagram Ads Agency', 'Social Media Advertising', 'Meta Ads Agency India', 'Facebook Ads USA'],
  },
];
